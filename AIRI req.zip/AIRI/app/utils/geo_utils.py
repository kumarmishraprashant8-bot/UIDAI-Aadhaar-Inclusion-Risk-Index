"""
app/utils/geo_utils.py
Geographic utilities for GeoJSON processing and TopoJSON generation
"""

import json
import geopandas as gpd
from pathlib import Path
from typing import Dict, Any
import topojson as tp


def validate_geojson(geojson_path: str) -> Dict[str, Any]:
    """
    Validate GeoJSON file for AIRI requirements.
    
    Requirements:
    - WGS84 (EPSG:4326) coordinate system
    - Properties: district_name, district_id, state_name
    - Valid geometry
    
    Args:
        geojson_path: Path to GeoJSON file
    
    Returns:
        Dict with validation results
    """
    try:
        gdf = gpd.read_file(geojson_path)
        
        # Check CRS
        if gdf.crs is None:
            return {"valid": False, "error": "No CRS defined"}
        
        if gdf.crs.to_epsg() != 4326:
            return {"valid": False, "error": f"CRS must be EPSG:4326, got {gdf.crs}"}
        
        # Check required properties
        required_props = ['district_name', 'district_id', 'state_name']
        missing_props = [prop for prop in required_props if prop not in gdf.columns]
        
        if missing_props:
            return {"valid": False, "error": f"Missing properties: {missing_props}"}
        
        # Check geometry validity
        invalid_geom = gdf[~gdf.geometry.is_valid]
        if len(invalid_geom) > 0:
            return {"valid": False, "error": f"{len(invalid_geom)} invalid geometries"}
        
        return {
            "valid": True,
            "districts": len(gdf),
            "states": gdf['state_name'].nunique(),
            "bounds": gdf.total_bounds.tolist()
        }
    
    except Exception as e:
        return {"valid": False, "error": str(e)}


def reproject_to_wgs84(geojson_path: str, output_path: str) -> bool:
    """
    Reproject GeoJSON to WGS84 if needed.
    
    Args:
        geojson_path: Input GeoJSON path
        output_path: Output GeoJSON path
    
    Returns:
        True if reprojection was needed and successful
    """
    try:
        gdf = gpd.read_file(geojson_path)
        
        if gdf.crs is None or gdf.crs.to_epsg() != 4326:
            gdf = gdf.to_crs(epsg=4326)
            gdf.to_file(output_path, driver='GeoJSON')
            return True
        
        return False
    
    except Exception as e:
        raise ValueError(f"Reprojection failed: {e}")


def generate_topojson(geojson_path: str, output_path: str, simplify: float = 0.001) -> Dict[str, Any]:
    """
    Generate simplified TopoJSON from GeoJSON for web mapping.
    
    Args:
        geojson_path: Input GeoJSON path
        output_path: Output TopoJSON path
        simplify: Simplification tolerance (degrees)
    
    Returns:
        Generation statistics
    """
    try:
        # Read GeoJSON
        gdf = gpd.read_file(geojson_path)
        
        # Simplify geometry for web performance
        gdf['geometry'] = gdf.geometry.simplify(simplify, preserve_topology=True)
        
        # Convert to TopoJSON
        topo = tp.Topology(gdf, prequantize=False)
        
        # Save TopoJSON
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(topo.to_dict(), f, separators=(',', ':'))
        
        return {
            "districts": len(gdf),
            "file_size_kb": Path(output_path).stat().st_size / 1024,
            "simplification": simplify
        }
    
    except Exception as e:
        raise ValueError(f"TopoJSON generation failed: {e}")


def normalize_district_names(name: str) -> str:
    """
    Normalize district names for consistent joining.
    
    Args:
        name: Raw district name
    
    Returns:
        Normalized district name
    """
    if not name:
        return ""
    
    # Convert to lowercase, remove extra spaces
    normalized = str(name).lower().strip()
    
    # Remove common prefixes/suffixes
    normalized = normalized.replace(" district", "").replace("district ", "")
    normalized = normalized.replace(" div", "").replace("div ", "")
    
    # Standardize common variations
    replacements = {
        "bengaluru": "bangalore",
        "mumbai": "bombay",
        "kolkata": "calcutta",
        "chennai": "madras",
        "thiruvananthapuram": "trivandrum"
    }
    
    for old, new in replacements.items():
        if old in normalized:
            normalized = normalized.replace(old, new)
    
    return normalized


def join_scores_to_geojson(geojson_path: str, scores_data: list, output_path: str) -> Dict[str, Any]:
    """
    Join AIRI scores to GeoJSON districts.
    
    Args:
        geojson_path: Input GeoJSON path
        scores_data: List of district scores
        output_path: Output GeoJSON with scores
    
    Returns:
        Join statistics
    """
    try:
        gdf = gpd.read_file(geojson_path)
        
        # Normalize district names for joining
        gdf['district_norm'] = gdf['district_name'].apply(normalize_district_names)
        
        # Create scores lookup
        scores_dict = {}
        for score in scores_data:
            norm_name = normalize_district_names(score.get('district', ''))
            scores_dict[norm_name] = score
        
        # Join scores
        matched = 0
        for idx, row in gdf.iterrows():
            norm_name = row['district_norm']
            if norm_name in scores_dict:
                score_data = scores_dict[norm_name]
                gdf.loc[idx, 'airi_score'] = score_data.get('risk_score', 0)
                gdf.loc[idx, 'risk_band'] = score_data.get('risk_band', 'low')
                gdf.loc[idx, 'citizens_impacted'] = score_data.get('citizens_impacted', 0)
                matched += 1
        
        # Fill unmatched with defaults
        gdf['airi_score'] = gdf['airi_score'].fillna(0)
        gdf['risk_band'] = gdf['risk_band'].fillna('low')
        gdf['citizens_impacted'] = gdf['citizens_impacted'].fillna(0)
        
        # Drop temporary column
        gdf = gdf.drop('district_norm', axis=1)
        
        # Save
        gdf.to_file(output_path, driver='GeoJSON')
        
        return {
            "total_districts": len(gdf),
            "matched_scores": matched,
            "match_rate": matched / len(gdf) if len(gdf) > 0 else 0
        }
    
    except Exception as e:
        raise ValueError(f"Score joining failed: {e}")