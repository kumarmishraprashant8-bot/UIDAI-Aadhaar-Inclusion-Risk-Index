"""
app/utils/column_mapper.py
Fuzzy column mapping for uploaded CSVs
"""

import pandas as pd
import yaml
from pathlib import Path
from difflib import SequenceMatcher
from typing import Dict, List, Optional


# Canonical schema
CANONICAL_FIELDS = {
    'record_id': ['id', 'record', 'record_id', 'transaction_id'],
    'timestamp': ['date', 'timestamp', 'datetime', 'created_at', 'event_date'],
    'state': ['state', 'st', 'state_name'],
    'district': ['district', 'dist', 'district_name'],
    'subdistrict': ['subdistrict', 'subdist', 'tahsil', 'block'],
    'center_id': ['center_id', 'centre_id', 'enrollment_center', 'center'],
    'pincode': ['pincode', 'pin', 'postal_code'],
    'age': ['age', 'applicant_age'],
    'dob': ['dob', 'date_of_birth', 'birth_date'],
    'gender': ['gender', 'sex'],
    'enrolment_channel': ['channel', 'enrolment_channel', 'enrollment_type'],
    'update_type': ['update_type', 'service_type', 'request_type'],
    'device_id': ['device_id', 'device', 'machine_id'],
    'operator_id': ['operator_id', 'operator', 'agent_id'],
    'outcome': ['outcome', 'status', 'result'],
    'processing_time_seconds': ['processing_time', 'duration', 'time_taken'],
    'biometric_hash': ['biometric_hash', 'bio_hash', 'fingerprint_hash'],
    'reason_code': ['reason_code', 'error_code', 'rejection_reason'],
    'duplicate_flag': ['duplicate', 'is_duplicate', 'dup_flag']
}


def fuzzy_match(input_col: str, canonical_aliases: List[str], threshold: float = 0.6) -> Optional[str]:
    """
    Fuzzy match input column to canonical aliases.
    
    Args:
        input_col: Column name from uploaded CSV
        canonical_aliases: List of known aliases for a canonical field
        threshold: Similarity threshold (0-1)
    
    Returns:
        Best matching alias or None
    """
    input_col_lower = input_col.lower().strip()
    
    best_score = 0.0
    best_match = None
    
    for alias in canonical_aliases:
        score = SequenceMatcher(None, input_col_lower, alias.lower()).ratio()
        if score > best_score and score >= threshold:
            best_score = score
            best_match = alias
    
    return best_match


def map_columns(df: pd.DataFrame, custom_map: Optional[Dict[str, str]] = None) -> pd.DataFrame:
    """
    Map uploaded CSV columns to canonical schema using fuzzy matching.
    
    Args:
        df: Input DataFrame
        custom_map: Optional manual mapping override (from column_map.yaml)
    
    Returns:
        DataFrame with canonical column names
    """
    column_mapping = {}
    
    # Load custom mapping if exists
    custom_mapping_file = Path("column_map.yaml")
    if custom_mapping_file.exists():
        with open(custom_mapping_file) as f:
            custom_map = yaml.safe_load(f) or {}
    else:
        custom_map = custom_map or {}
    
    # First apply custom mapping
    for input_col in df.columns:
        if input_col in custom_map:
            column_mapping[input_col] = custom_map[input_col]
    
    # Then fuzzy match unmapped columns
    for input_col in df.columns:
        if input_col in column_mapping:
            continue  # Already mapped
        
        for canonical_field, aliases in CANONICAL_FIELDS.items():
            if fuzzy_match(input_col, aliases):
                column_mapping[input_col] = canonical_field
                break
    
    # Rename columns
    df_mapped = df.rename(columns=column_mapping)
    
    # Log unmapped columns
    unmapped = set(df.columns) - set(column_mapping.keys())
    if unmapped:
        print(f"Warning: Unmapped columns: {unmapped}")
    
    print(f"Mapped columns: {column_mapping}")
    
    return df_mapped