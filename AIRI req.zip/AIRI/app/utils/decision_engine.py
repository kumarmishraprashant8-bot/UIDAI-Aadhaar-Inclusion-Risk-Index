"""
app/utils/decision_engine.py
Decision logic: Map risk drivers and risk bands to recommended UIDAI actions
Includes intervention simulation with expected impact and cost estimates
"""

from app.schemas import RecommendedAction
from typing import Dict, Any, List
import numpy as np


def shap_to_sentence(drivers) -> str:
    """
    Convert top 3 SHAP drivers to human-readable explanation sentence.
    
    Args:
        drivers: List of ShapDriver objects or dicts (top 3)
    
    Returns:
        Single explanatory sentence (max 200 chars)
    """
    if not drivers:
        return "Insufficient data to generate explanation."
    
    # Get top 3 drivers
    drivers = drivers[:3]
    
    # Build readable feature names
    def humanize_feature(feat_name: str) -> str:
        # Enhanced feature name mapping
        feature_map = {
            'failure_rate_30d': 'High enrollment failure rate',
            'biometric_fail_rate_30d': 'Biometric capture failures',
            'device_burstiness': 'Device performance inconsistency',
            'processing_time_ratio': 'Slow processing times',
            'operational_stress': 'Operational system stress',
            'repeat_rate': 'High repeat enrollment attempts',
            'elderly_ratio': 'High elderly population ratio',
            'center_congestion': 'Enrollment center congestion',
            'mobile_camp_coverage': 'Limited mobile camp coverage',
            'events_7d_to_30d_ratio': 'Recent enrollment volume decline',
            'volume_trend': 'Enrollment volume trend changes'
        }
        
        if feat_name in feature_map:
            return feature_map[feat_name]
        
        # Fallback to generic transformation
        return (feat_name
                .replace('_', ' ')
                .replace('30d', 'in last 30 days')
                .replace('14d', 'in last 14 days')
                .replace('7d', 'in last 7 days')
                .replace('rate', 'rate')
                .title())
    
    # Get attributes from either object or dict
    def get_attr(d, key):
        if isinstance(d, dict):
            return d.get(key, 0)
        return getattr(d, key, 0)
    
    # Primary driver
    top_driver = drivers[0]
    top_name = humanize_feature(get_attr(top_driver, 'feature'))
    
    # Build concise explanation focusing on top driver
    if len(drivers) >= 2:
        second_name = humanize_feature(get_attr(drivers[1], 'feature'))
        sentence = f"{top_name} and {second_name.lower()} are driving exclusion risk."
    else:
        sentence = f"{top_name} is the primary driver of exclusion risk."
    
    return sentence[:200]  # Max 200 chars


def get_recommended_action(risk_band: str, drivers, district_data: dict) -> RecommendedAction:
    """
    Map risk band + drivers to exactly ONE recommended UIDAI action.
    
    Decision logic with contextual driver analysis:
    - CRITICAL: Deploy mobile camp (highest impact, immediate)
    - HIGH: Audit devices + retrain (targeted fix)
    - MEDIUM: Extend center hours (accessibility improvement)
    - LOW: Monitor (maintain current state)
    
    Args:
        risk_band: 'critical', 'high', 'medium', 'low'
        drivers: List of top 3 ShapDriver objects
        district_data: District metadata for contextual decisions
    
    Returns:
        RecommendedAction with action, expected_impact, cost_band, priority
    """
    
    if risk_band == "critical":
        # Critical risk -> Deploy mobile camp (immediate intervention)
        return RecommendedAction(
            action="Deploy mobile enrollment camp immediately within 7 days",
            expected_impact="15-25% reduction in exclusion risk within 30 days",
            cost_band="Medium",
            priority="High"
        )
    
    elif risk_band == "high":
        # Analyze top driver for targeted intervention
        top_driver = drivers[0] if drivers else None
        
        if top_driver:
            feature_name = getattr(top_driver, 'feature', '') if hasattr(top_driver, 'feature') else top_driver.get('feature', '')
            
            if 'biometric' in feature_name.lower() or 'device' in feature_name.lower():
                # Biometric/device issues -> Audit and retrain
                return RecommendedAction(
                    action="Audit enrollment devices and retrain operators within 14 days",
                    expected_impact="10-20% reduction in biometric failure rates",
                    cost_band="Low",
                    priority="Medium"
                )
            elif 'processing_time' in feature_name.lower() or 'operational' in feature_name.lower():
                # Processing efficiency issues -> Optimize procedures
                return RecommendedAction(
                    action="Optimize enrollment procedures and audit center operations",
                    expected_impact="12-18% improvement in processing efficiency",
                    cost_band="Low",
                    priority="Medium"
                )
            elif 'congestion' in feature_name.lower() or 'volume' in feature_name.lower():
                # Capacity issues -> Extend hours
                return RecommendedAction(
                    action="Extend enrollment center hours and increase staffing",
                    expected_impact="15-20% improvement in service capacity",
                    cost_band="Medium",
                    priority="Medium"
                )
        
        # Default high-risk action
        return RecommendedAction(
            action="Audit enrollment devices and retrain operators within 14 days",
            expected_impact="10-20% reduction in failure rates",
            cost_band="Low",
            priority="Medium"
        )
    
    elif risk_band == "medium":
        # Moderate risk -> Accessibility improvement
        return RecommendedAction(
            action="Extend enrollment center operating hours by 2-3 hours daily",
            expected_impact="8-12% improvement in citizen accessibility",
            cost_band="Low",
            priority="Low"
        )
    
    else:  # low
        # Low risk -> Maintain monitoring
        return RecommendedAction(
            action="Continue routine monitoring and quarterly performance audits",
            expected_impact="Maintain current performance levels and prevent degradation",
            cost_band="Low",
            priority="Low"
        )


def simulate_intervention(district_id: str, action: str, intensity: float = 1.0, 
                         current_airi_score: int = 50, citizens_impacted: int = 10000) -> Dict[str, Any]:
    """
    Simulate expected impact of UIDAI intervention.
    
    Args:
        district_id: District identifier
        action: Recommended action string
        intensity: Intervention intensity (0.5 to 1.5, default 1.0)
        current_airi_score: Current AIRI risk score (0-100)
        citizens_impacted: Current estimated citizens at risk
    
    Returns:
        Dict with simulation results including before/after metrics, costs, and confidence intervals
    """
    
    # Impact multipliers by action type (conservative estimates)
    impact_table = {
        'mobile_camp': {
            'baseline_reduction': 0.25,  # 25% reduction in exclusion risk
            'cost_per_citizen': 15,      # ₹15 per citizen reached
            'implementation_days': 7,
            'uptake_rate': 0.7          # 70% of target population reached
        },
        'audit_devices': {
            'baseline_reduction': 0.18,  # 18% reduction in device-related failures
            'cost_per_citizen': 8,       # ₹8 per citizen (indirect benefit)
            'implementation_days': 14,
            'uptake_rate': 0.8          # 80% effectiveness
        },
        'extend_hours': {
            'baseline_reduction': 0.12,  # 12% improvement in accessibility
            'cost_per_citizen': 5,       # ₹5 per citizen (operational cost)
            'implementation_days': 3,
            'uptake_rate': 0.6          # 60% utilization of extended hours
        },
        'monitor': {
            'baseline_reduction': 0.02,  # 2% improvement from monitoring
            'cost_per_citizen': 1,       # ₹1 per citizen (monitoring cost)
            'implementation_days': 1,
            'uptake_rate': 0.9          # 90% monitoring coverage
        }
    }
    
    # Determine action type from action string
    action_lower = action.lower()
    if 'mobile' in action_lower or 'camp' in action_lower:
        action_type = 'mobile_camp'
    elif 'audit' in action_lower or 'device' in action_lower or 'retrain' in action_lower:
        action_type = 'audit_devices'
    elif 'extend' in action_lower or 'hours' in action_lower:
        action_type = 'extend_hours'
    else:
        action_type = 'monitor'
    
    # Get impact parameters
    params = impact_table[action_type]
    
    # Calculate impact with intensity adjustment
    baseline_reduction = params['baseline_reduction'] * intensity
    uptake = params['uptake_rate']
    
    # Effective reduction considering uptake and intensity
    effective_reduction = baseline_reduction * uptake
    
    # Apply reduction to AIRI score (with diminishing returns for low scores)
    score_reduction_factor = min(0.4, effective_reduction)  # Cap at 40% reduction
    if current_airi_score < 30:
        score_reduction_factor *= 0.5  # Harder to improve already good scores
    
    new_airi_score = max(0, int(current_airi_score * (1 - score_reduction_factor)))
    
    # Calculate citizens protected
    citizens_protected = int(citizens_impacted * effective_reduction)
    new_citizens_impacted = max(0, citizens_impacted - citizens_protected)
    
    # Cost estimation
    base_cost_per_citizen = params['cost_per_citizen']
    total_cost = int(citizens_impacted * base_cost_per_citizen * intensity)
    cost_per_citizen_protected = int(total_cost / max(1, citizens_protected))
    
    # Confidence intervals (conservative: ±20%, optimistic: +50%)
    conservative_multiplier = 0.5
    optimistic_multiplier = 1.5
    
    conservative_protected = int(citizens_protected * conservative_multiplier)
    optimistic_protected = int(citizens_protected * optimistic_multiplier)
    
    conservative_score = max(0, int(current_airi_score - (current_airi_score - new_airi_score) * conservative_multiplier))
    optimistic_score = max(0, int(current_airi_score - (current_airi_score - new_airi_score) * optimistic_multiplier))
    
    # Cost effectiveness rating
    if cost_per_citizen_protected <= 20:
        cost_effectiveness = "High"
    elif cost_per_citizen_protected <= 50:
        cost_effectiveness = "Medium"
    else:
        cost_effectiveness = "Low"
    
    return {
        'district_id': district_id,
        'action': action,
        'intensity': intensity,
        'implementation_days': params['implementation_days'],
        
        # Before metrics
        'before': {
            'airi_score': current_airi_score,
            'citizens_impacted': citizens_impacted,
            'risk_level': get_risk_level(current_airi_score)
        },
        
        # After metrics (point estimates)
        'after': {
            'airi_score': new_airi_score,
            'citizens_impacted': new_citizens_impacted,
            'risk_level': get_risk_level(new_airi_score)
        },
        
        # Impact summary
        'impact': {
            'citizens_protected': citizens_protected,
            'airi_score_reduction': current_airi_score - new_airi_score,
            'relative_improvement': f"{effective_reduction:.1%}",
            'uptake_rate': f"{uptake:.1%}"
        },
        
        # Cost analysis
        'cost': {
            'total_cost_inr': total_cost,
            'cost_per_citizen_protected': cost_per_citizen_protected,
            'cost_effectiveness': cost_effectiveness,
            'budget_category': params['cost_per_citizen'] * 10000  # Budget for 10k citizens
        },
        
        # Confidence intervals
        'confidence_intervals': {
            'conservative': {
                'citizens_protected': conservative_protected,
                'airi_score': conservative_score,
                'description': "50% of point estimate (conservative scenario)"
            },
            'optimistic': {
                'citizens_protected': optimistic_protected,
                'airi_score': optimistic_score,
                'description': "150% of point estimate (optimistic scenario)"
            }
        },
        
        # Metadata
        'simulation_date': np.datetime64('now').astype(str),
        'model_version': '1.0',
        'assumptions': f"Based on {action_type} intervention with {uptake:.0%} uptake rate"
    }


def get_risk_level(airi_score: int) -> str:
    """Convert AIRI score to risk level string"""
    if airi_score >= 75:
        return "Critical"
    elif airi_score >= 50:
        return "High"
    elif airi_score >= 25:
        return "Medium"
    else:
        return "Low"