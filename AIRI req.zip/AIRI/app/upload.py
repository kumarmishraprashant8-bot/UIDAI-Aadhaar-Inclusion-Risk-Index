"""
app/upload.py
File upload processing and storage
"""

import csv
import json
import zipfile
import uuid
from pathlib import Path
from typing import Dict
from fastapi import UploadFile


async def process_upload(file: UploadFile) -> Dict:
    """
    Process uploaded CSV/ZIP file.
    Applies column mapping and stores processed data.
    
    Args:
        file: UploadFile object (CSV or ZIP)
    
    Returns:
        Dict with:
        - rows: Number of rows processed
        - mapped_columns: List of mapped column names
        - file_id: Unique identifier for this upload
    """
    file_id = str(uuid.uuid4())[:8]
    upload_dir = Path(f"data/uploads/{file_id}")
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Read file into memory
        contents = await file.read()
        
        # Handle ZIP
        if file.filename.endswith('.zip'):
            zip_path = upload_dir / "temp.zip"
            with open(zip_path, 'wb') as f:
                f.write(contents)
            
            # Extract all CSVs
            with zipfile.ZipFile(zip_path) as z:
                csv_files = [n for n in z.namelist() if n.endswith('.csv')]
                for csv_name in csv_files:
                    with z.open(csv_name) as csv_file:
                        target = upload_dir / csv_name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with open(target, 'wb') as f:
                            f.write(csv_file.read())
            
            zip_path.unlink()  # Clean up temp
            
            # Merge all CSVs
            all_rows = []
            for csv_file in upload_dir.glob('**/*.csv'):
                with open(csv_file) as f:
                    reader = csv.DictReader(f)
                    all_rows.extend(reader)
            
            n_rows = len(all_rows)
            mapped_cols = list(all_rows[0].keys()) if all_rows else []
        
        else:  # Single CSV
            csv_path = upload_dir / file.filename
            with open(csv_path, 'wb') as f:
                f.write(contents)
            
            # Count rows
            with open(csv_path) as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                n_rows = len(rows)
                mapped_cols = list(rows[0].keys()) if rows else []
        
        return {
            "rows": n_rows,
            "mapped_columns": mapped_cols,
            "file_id": file_id
        }
    
    except Exception as e:
        raise ValueError(f"Failed to process upload: {str(e)}")
