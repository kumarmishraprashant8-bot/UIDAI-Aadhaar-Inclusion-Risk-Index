"""
app/main.py
FastAPI backend for AIRI
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import json
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from app.schemas import DistrictScore, ScoreRequest, HealthResponse
from app.scoring import score_districts
from app.upload import process_upload
from app.utils.column_mapper import map_columns
from app.utils.decision_engine import simulate_intervention

app = FastAPI(title="AIRI API", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure data directory
Path("data").mkdir(exist_ok=True)

# Serve static files (for TopoJSON and other assets)
static_dir = Path("static")
static_dir.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


# Simulation request schema
class SimulationRequest(BaseModel):
    district_id: str
    action: str
    intensity: Optional[float] = 1.0
    current_airi_score: Optional[int] = None
    citizens_impacted: Optional[int] = None


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        model_loaded=Path("models/model.joblib").exists(),
        timestamp=datetime.utcnow().isoformat()
    )


@app.post("/upload")
async def upload_data(file: UploadFile = File(...)):
    """
    Upload CSV/ZIP file for processing.
    Applies column mapping and stores processed data.
    """
    try:
        # Process upload
        result = await process_upload(file)
        
        return JSONResponse(content={
            "status": "success",
            "rows_processed": result["rows"],
            "columns_mapped": result["mapped_columns"],
            "file_id": result["file_id"]
        })
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/score", response_model=List[DistrictScore])
async def score_request(request: ScoreRequest):
    """
    Score districts for exclusion risk.
    Returns AIRI scores with explainability and recommendations.
    """
    try:
        scores = score_districts(
            file_id=request.file_id,
            districts=request.districts
        )
        return scores
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/scores/latest", response_model=List[DistrictScore])
async def get_latest_scores(limit: Optional[int] = 100):
    """
    Retrieve latest computed scores from JSON storage.
    """
    try:
        scores_file = Path("data/demo_scores.json")
        
        if not scores_file.exists():
            return []
        
        with open(scores_file) as f:
            all_scores = json.load(f)
        
        # Sort by risk score descending and limit
        all_scores.sort(key=lambda x: x['risk_score'], reverse=True)
        return all_scores[:limit]
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/scores/{district_id}", response_model=DistrictScore)
async def get_district_score(district_id: str):
    """
    Retrieve score for specific district.
    """
    try:
        scores_file = Path("data/demo_scores.json")
        
        if not scores_file.exists():
            raise HTTPException(status_code=404, detail="No scores available")
        
        with open(scores_file) as f:
            all_scores = json.load(f)
        
        district_score = next((s for s in all_scores if s['district'] == district_id), None)
        
        if not district_score:
            raise HTTPException(status_code=404, detail=f"District {district_id} not found")
        
        return district_score
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/simulate_intervention")
async def simulate_intervention_endpoint(request: SimulationRequest):
    """
    Simulate expected impact of UIDAI intervention.
    
    Returns before/after metrics, cost estimates, and confidence intervals.
    """
    try:
        # Get current district data if not provided
        if request.current_airi_score is None or request.citizens_impacted is None:
            scores_file = Path("data/demo_scores.json")
            
            if scores_file.exists():
                with open(scores_file) as f:
                    all_scores = json.load(f)
                
                district_score = next((s for s in all_scores if s['district'] == request.district_id), None)
                
                if district_score:
                    current_airi_score = request.current_airi_score or district_score['risk_score']
                    citizens_impacted = request.citizens_impacted or district_score['citizens_impacted']
                else:
                    # Fallback defaults
                    current_airi_score = request.current_airi_score or 50
                    citizens_impacted = request.citizens_impacted or 10000
            else:
                # Fallback defaults
                current_airi_score = request.current_airi_score or 50
                citizens_impacted = request.citizens_impacted or 10000
        else:
            current_airi_score = request.current_airi_score
            citizens_impacted = request.citizens_impacted
        
        # Run simulation
        simulation_result = simulate_intervention(
            district_id=request.district_id,
            action=request.action,
            intensity=request.intensity,
            current_airi_score=current_airi_score,
            citizens_impacted=citizens_impacted
        )
        
        return JSONResponse(content=simulation_result)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "AIRI API",
        "version": "1.0.0",
        "description": "Aadhaar Inclusion Risk Index - Predictive + Prescriptive System",
        "endpoints": {
            "health": "/health",
            "upload": "/upload",
            "score": "/score",
            "latest_scores": "/scores/latest",
            "district_score": "/scores/{district_id}",
            "simulate": "/simulate_intervention",
            "docs": "/docs"
        },
        "demo_mode": True,
        "privacy_compliant": True
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)