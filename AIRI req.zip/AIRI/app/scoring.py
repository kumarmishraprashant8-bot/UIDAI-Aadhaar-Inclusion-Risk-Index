"""
app/scoring.py
Core scoring logic with SHAP explainability
"""

import joblib
import json
import pandas as pd
import numpy as np
import shap
from pathlib import Path
from typing import List, Dict, Optional
from app.schemas import DistrictScore, ShapDriver, RecommendedAction
from app.utils.decision_engine import get_recommended_action, shap_to_sentence


# Load model and metadata
MODEL_PATH = Path("models/model.joblib")
METADATA_PATH = Path("models/feature_metadata.json")

_model = None
_metadata = None


def compute_airi_score(risk_prob: float, confidence: float = 0.85) -> int:
    """
    Compute AIRI score (0-100) from risk probability with confidence adjustment.
    
    AIRI = raw_probability * 100 * confidence_factor
    - confidence_factor caps lower probability with high variance
    - Ensures predictability weight
    
    Args:
        risk_prob: Raw model probability (0-1)
        confidence: Model confidence score (0-1)
    
    Returns:
        AIRI score (0-100, integer)
    """
    airi = risk_prob * 100 * (0.8 + 0.2 * confidence)
    return min(100, max(0, int(airi)))


def validate_airi_score(score: int, explanation: str) -> tuple:
    """
    Validate AIRI score output.
    
    Returns:
        (is_valid, error_message)
    """
    if not isinstance(score, int) or score < 0 or score > 100:
        return False, f"AIRI score must be 0-100, got {score}"
    if not explanation or len(explanation.strip()) == 0:
        return False, "Explanation cannot be empty"
    if len(explanation) > 200:
        return False, f"Explanation too long ({len(explanation)} > 200)"
    return True, None


def load_model():
    """Lazy load model and metadata"""
    global _model, _metadata
    
    if _model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError("Model file not found. Run training first.")
        _model = joblib.load(MODEL_PATH)
    
    if _metadata is None:
        if not METADATA_PATH.exists():
            raise FileNotFoundError("Metadata file not found. Run training first.")
        with open(METADATA_PATH) as f:
            _metadata = json.load(f)
    
    return _model, _metadata


def prepare_features(df: pd.DataFrame, metadata: Dict) -> pd.DataFrame:
    """
    Prepare features matching training schema.
    Fills missing columns with 0.
    """
    feature_cols = metadata['features']
    
    # Ensure all required columns exist
    for col in feature_cols:
        if col not in df.columns:
            df[col] = 0
    
    return df[feature_cols].fillna(0)


def compute_shap_drivers(model, X: pd.DataFrame, metadata: Dict) -> List[List[ShapDriver]]:
    """
    Compute top-3 SHAP drivers for each district.
    
    Returns:
        List of driver lists (one per district)
    """
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    if isinstance(shap_values, list):
        shap_values = shap_values[1]  # positive class
    
    all_drivers = []
    
    for i in range(len(X)):
        # Get feature contributions for this district
        feature_shap = pd.DataFrame({
            'feature': X.columns,
            'shap_value': shap_values[i],
            'feature_value': X.iloc[i].values
        })
        
        # Top 3 by absolute SHAP
        top_3 = feature_shap.reindex(feature_shap['shap_value'].abs().nlargest(3).index)
        
        drivers = [
            ShapDriver(
                feature=row['feature'],
                shap_value=float(row['shap_value']),
                feature_value=float(row['feature_value'])
            )
            for _, row in top_3.iterrows()
        ]
        
        all_drivers.append(drivers)
    
    return all_drivers


def compute_airi_score(risk_prob: float, confidence: float = 0.85) -> int:
    """
    Compute AIRI score (0-100) from risk probability with confidence adjustment.
    
    AIRI = raw_probability * 100 * confidence_factor
    - confidence_factor caps lower probability with high variance
    - Ensures predictability weight
    
    Args:
        risk_prob: Raw model probability (0-1)
        confidence: Model confidence score (0-1)
    
    Returns:
        AIRI score (0-100, integer)
    """
    airi = risk_prob * 100 * (0.8 + 0.2 * confidence)
    return min(100, max(0, int(airi)))


def validate_airi_score(score: int, explanation: str) -> tuple:
    """
    Validate AIRI score output.
    
    Returns:
        (is_valid, error_message)
    """
    if not isinstance(score, int) or score < 0 or score > 100:
        return False, f"AIRI score must be 0-100, got {score}"
    if not explanation or len(explanation.strip()) == 0:
        return False, "Explanation cannot be empty"
    if len(explanation) > 200:
        return False, f"Explanation too long ({len(explanation)} > 200)"
    return True, None


def score_districts(file_id: Optional[str] = None, districts: Optional[List[str]] = None) -> List[DistrictScore]:
    """
    Score districts for exclusion risk.
    
    Pipeline:
    1. Load model + metadata
    2. Prepare features from input data
    3. Compute raw risk probability
    4. Convert to AIRI score (0-100)
    5. Compute SHAP explainability
    6. Map to risk band + recommended action
    7. Validate outputs
    
    Args:
        file_id: Uploaded file identifier (optional for demo)
        districts: Optional list of specific districts to score
    
    Returns:
        List of DistrictScore objects with predictions, explainability, and recommendations
    """
    model, metadata = load_model()
    
    # Load data (for demo, use synthetic)
    # In production, load from file_id stored in data/uploads/{file_id}
    df = pd.read_csv("data/synthetic_districts.csv")
    
    if districts:
        df = df[df['district'].isin(districts)]
    
    if len(df) == 0:
        return []
    
    # Prepare features (fill missing with 0)
    X = prepare_features(df, metadata)
    
    # Predict risk probabilities
    risk_probs = model.predict(X)
    
    # Compute confidence (simple: use model's own prediction variance)
    # For demo: use proximity to decision boundary as confidence
    confidence = np.abs(risk_probs - 0.5) * 2  # 0-1, higher when farther from 0.5
    
    # Convert to AIRI scores
    airi_scores = [compute_airi_score(prob, conf) for prob, conf in zip(risk_probs, confidence)]
    
    # Compute SHAP drivers
    shap_drivers = compute_shap_drivers(model, X, metadata)
    
    # Build results
    results = []
    
    for i, row in df.iterrows():
        district_name = row['district']
        state = row.get('state', 'Unknown')
        airi_score = airi_scores[i]
        drivers = shap_drivers[i]
        
        # Map AIRI score to risk band
        if airi_score >= 75:
            risk_band = "critical"
        elif airi_score >= 50:
            risk_band = "high"
        elif airi_score >= 25:
            risk_band = "medium"
        else:
            risk_band = "low"
        
        # Generate explanation sentence
        explanation = shap_to_sentence(drivers)
        
        # Validate explanation
        is_valid, error_msg = validate_airi_score(airi_score, explanation)
        if not is_valid:
            explanation = f"Unable to generate explanation: {error_msg}"
        
        # Get recommended action
        action = get_recommended_action(risk_band, drivers, row)
        
        # Estimate citizens impacted
        # Heuristic: AIRI score * (affected % of population)
        # Assume AIRI >= 50 means ~50% of population at risk
        impact_factor = max(0.1, (airi_score - 25) / 100)  # 0.1 to 1.0
        citizens_impacted = int(impact_factor * row.get('total_population', 50000))
        
        result = DistrictScore(
            district=district_name,
            state=state,
            risk_score=airi_score,
            risk_band=risk_band,
            shap_drivers=drivers,
            explanation=explanation,
            recommended_action=action,
            citizens_impacted=citizens_impacted,
            latitude=row.get('latitude', 0.0),
            longitude=row.get('longitude', 0.0)
        )
        
        results.append(result)
    
    # Save to JSON for /scores/latest endpoint
    output_path = Path("data/demo_scores.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump([r.dict() for r in results], f, indent=2)
    
    return results