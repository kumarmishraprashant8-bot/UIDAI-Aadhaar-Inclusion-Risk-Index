from pydantic import BaseModel
from typing import List, Optional

class ShapDriver(BaseModel):
    feature: str
    shap_value: float
    feature_value: float

class RecommendedAction(BaseModel):
    action: str
    expected_impact: str
    cost_band: str
    priority: str

class DistrictScore(BaseModel):
    district: str
    state: str
    risk_score: int
    risk_band: str
    shap_drivers: List[ShapDriver]
    explanation: str
    recommended_action: RecommendedAction
    citizens_impacted: int
    latitude: float
    longitude: float

class ScoreRequest(BaseModel):
    file_id: Optional[str] = None
    districts: Optional[List[str]] = None

class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    timestamp: str