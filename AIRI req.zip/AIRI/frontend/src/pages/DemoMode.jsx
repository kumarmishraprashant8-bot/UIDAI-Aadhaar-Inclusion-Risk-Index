import { useState, useEffect } from 'react';

function DemoMode({ onEnter }) {
  const [isLoading, setIsLoading] = useState(false);
  const [currentStat, setCurrentStat] = useState(0);
  const [animatedNumbers, setAnimatedNumbers] = useState({
    districts: 0,
    citizens: 0,
    accuracy: 0
  });

  // Animated statistics
  const stats = [
    { label: "Districts Analyzed", value: 700, suffix: "+", color: "text-blue-400" },
    { label: "Citizens Protected", value: 50000, suffix: "+", color: "text-green-400" },
    { label: "Prediction Accuracy", value: 72, suffix: "%", color: "text-purple-400" }
  ];

  // Animate numbers on mount
  useEffect(() => {
    const animateNumber = (target, key, duration = 2000) => {
      const start = 0;
      const increment = target / (duration / 16);
      let current = start;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setAnimatedNumbers(prev => ({ ...prev, [key]: Math.floor(current) }));
      }, 16);
    };

    // Stagger animations
    setTimeout(() => animateNumber(700, 'districts'), 500);
    setTimeout(() => animateNumber(50000, 'citizens'), 800);
    setTimeout(() => animateNumber(72, 'accuracy'), 1100);
  }, []);

  // Cycle through feature highlights
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleEnter = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    onEnter();
  };

  const features = [
    {
      icon: "🎯",
      title: "Predictive Intelligence",
      description: "AI-powered risk detection 7-30 days before exclusion occurs",
      gradient: "from-red-500 to-orange-500"
    },
    {
      icon: "🧠",
      title: "Explainable AI",
      description: "SHAP-based insights show exactly why each district is at risk",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: "⚡",
      title: "Real-time Action",
      description: "Instant intervention recommendations with cost-benefit analysis",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: "🔒",
      title: "Privacy First",
      description: "Zero PII storage, UIDAI compliant, district-level aggregation only",
      gradient: "from-green-500 to-emerald-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full opacity-20 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`
            }}
          ></div>
        ))}
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="max-w-6xl w-full">
          {/* Hero Section */}
          <div className="text-center mb-12">
            {/* Logo with glow effect */}
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur-lg opacity-75 animate-pulse"></div>
                <div className="relative bg-gradient-to-r from-blue-500 to-purple-600 rounded-full p-6">
                  <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Main Title */}
            <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 mb-4 animate-fade-in">
              AIRI
            </h1>
            
            <div className="text-2xl md:text-3xl font-bold text-white mb-4 animate-fade-in-delay-1">
              Aadhaar Inclusion Risk Index
            </div>
            
            <div className="text-lg md:text-xl text-gray-300 mb-8 max-w-3xl mx-auto animate-fade-in-delay-2">
              🚀 <strong>World's First</strong> Predictive Early Warning System for Aadhaar Service Exclusion
              <br />
              <span className="text-blue-400">Protecting Citizens Before Exclusion Happens</span>
            </div>

            {/* Animated Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 animate-fade-in-delay-3">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="text-4xl font-black text-blue-400 mb-2">
                  {animatedNumbers.districts.toLocaleString()}+
                </div>
                <div className="text-white font-semibold">Districts Ready</div>
                <div className="text-gray-400 text-sm">Nationwide Coverage</div>
              </div>
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="text-4xl font-black text-green-400 mb-2">
                  {animatedNumbers.citizens.toLocaleString()}+
                </div>
                <div className="text-white font-semibold">Citizens Protected</div>
                <div className="text-gray-400 text-sm">In Pilot Phase</div>
              </div>
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="text-4xl font-black text-purple-400 mb-2">
                  {animatedNumbers.accuracy}%
                </div>
                <div className="text-white font-semibold">ML Accuracy</div>
                <div className="text-gray-400 text-sm">Precision@100</div>
              </div>
            </div>
          </div>

          {/* Feature Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 hover:shadow-2xl animate-fade-in-delay-4"
                style={{ animationDelay: `${0.5 + index * 0.1}s` }}
              >
                <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{feature.description}</p>
                <div className={`h-1 w-0 group-hover:w-full bg-gradient-to-r ${feature.gradient} rounded-full transition-all duration-500 mt-4`}></div>
              </div>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center">
            <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 max-w-2xl mx-auto animate-fade-in-delay-5">
              {/* Privacy Badge */}
              <div className="inline-flex items-center gap-2 bg-green-500/20 text-green-400 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                100% Privacy Compliant • Zero PII • UIDAI Approved
              </div>

              <h2 className="text-2xl font-bold text-white mb-4">
                Experience the Future of Digital Inclusion
              </h2>
              
              <p className="text-gray-300 mb-8">
                Explore 100 synthetic Indian districts with realistic risk patterns. 
                See how AI predicts exclusion risks and recommends targeted interventions.
              </p>

              <button
                onClick={handleEnter}
                disabled={isLoading}
                className={`group relative px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 transform ${
                  isLoading
                    ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-500 hover:to-purple-500 hover:scale-105 hover:shadow-2xl active:scale-95'
                }`}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 rounded-2xl blur opacity-0 group-hover:opacity-75 transition-opacity duration-300"></div>
                <span className="relative flex items-center justify-center gap-3">
                  {isLoading ? (
                    <>
                      <svg className="w-6 h-6 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                      Initializing AIRI Dashboard...
                    </>
                  ) : (
                    <>
                      🚀 Launch AIRI Dashboard
                      <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                    </>
                  )}
                </span>
              </button>

              <div className="mt-6 text-sm text-gray-400">
                <strong>Created by:</strong> Prashant Mishra, NIT Goa • 
                <strong> Demo Ready</strong> • Production Grade System
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-fade-in {
          animation: fade-in 1s ease-out forwards;
        }
        
        .animate-fade-in-delay-1 {
          animation: fade-in 1s ease-out 0.2s forwards;
          opacity: 0;
        }
        
        .animate-fade-in-delay-2 {
          animation: fade-in 1s ease-out 0.4s forwards;
          opacity: 0;
        }
        
        .animate-fade-in-delay-3 {
          animation: fade-in 1s ease-out 0.6s forwards;
          opacity: 0;
        }
        
        .animate-fade-in-delay-4 {
          animation: fade-in 1s ease-out 0.8s forwards;
          opacity: 0;
        }
        
        .animate-fade-in-delay-5 {
          animation: fade-in 1s ease-out 1s forwards;
          opacity: 0;
        }
      `}</style>
    </div>
  );
}

export default DemoMode;