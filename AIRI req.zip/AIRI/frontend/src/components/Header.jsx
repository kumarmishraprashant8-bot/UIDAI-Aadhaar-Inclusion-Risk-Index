import React from 'react';

function Header({ stats, onRefresh }) {
  // Add some debugging to see what stats we're getting
  console.log('Header stats:', stats);
  
  return (
    <div className="bg-white/10 backdrop-blur-lg border-b border-white/20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              AIRI Dashboard
            </h1>
            <p className="text-gray-300 text-lg mt-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              Aadhaar Inclusion Risk Index — Predictive Early Warning System
            </p>
          </div>
          <button
            onClick={onRefresh}
            className="group px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-500 hover:to-purple-500 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl font-semibold flex items-center gap-2"
          >
            <svg className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Refresh Data
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* National AIRI Score */}
          <div className="group relative bg-gradient-to-br from-blue-500/20 to-blue-600/10 backdrop-blur-lg rounded-2xl p-6 border border-blue-400/30 hover:border-blue-400/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative flex justify-between items-start">
              <div>
                <p className="text-blue-300 text-sm font-semibold mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
                  National AIRI Score
                </p>
                <p className="text-5xl font-black text-white mb-2 group-hover:text-blue-300 transition-colors duration-300">
                  {stats?.nationalScore || 0}
                </p>
                <p className="text-blue-200 text-xs">Average across all districts</p>
              </div>
              <div className="text-4xl group-hover:scale-110 transition-transform duration-300">📊</div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>

          {/* High-Risk Districts */}
          <div className="group relative bg-gradient-to-br from-red-500/20 to-orange-600/10 backdrop-blur-lg rounded-2xl p-6 border border-red-400/30 hover:border-red-400/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative flex justify-between items-start">
              <div>
                <p className="text-red-300 text-sm font-semibold mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></span>
                  High-Risk Districts
                </p>
                <p className="text-5xl font-black text-white mb-2 group-hover:text-red-300 transition-colors duration-300">
                  {stats?.highRiskCount || 0}
                </p>
                <p className="text-red-200 text-xs">Require immediate action</p>
              </div>
              <div className="text-4xl group-hover:scale-110 transition-transform duration-300">⚠️</div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 to-orange-400 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>

          {/* Citizens at Risk */}
          <div className="group relative bg-gradient-to-br from-yellow-500/20 to-amber-600/10 backdrop-blur-lg rounded-2xl p-6 border border-yellow-400/30 hover:border-yellow-400/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative flex justify-between items-start">
              <div>
                <p className="text-yellow-300 text-sm font-semibold mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
                  Citizens at Risk
                </p>
                <p className="text-5xl font-black text-white mb-2 group-hover:text-yellow-300 transition-colors duration-300">
                  {stats?.citizensImpacted ? (stats.citizensImpacted / 1000000).toFixed(2) + 'M' : '0M'}
                </p>
                <p className="text-yellow-200 text-xs">Across high-risk districts</p>
              </div>
              <div className="text-4xl group-hover:scale-110 transition-transform duration-300">👥</div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-500 to-amber-400 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>

          {/* Events Processed */}
          <div className="group relative bg-gradient-to-br from-green-500/20 to-emerald-600/10 backdrop-blur-lg rounded-2xl p-6 border border-green-400/30 hover:border-green-400/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative flex justify-between items-start">
              <div>
                <p className="text-green-300 text-sm font-semibold mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                  Events Processed
                </p>
                <p className="text-5xl font-black text-white mb-2 group-hover:text-green-300 transition-colors duration-300">
                  {stats?.totalEvents ? (stats.totalEvents / 1000).toFixed(1) + 'K' : '0K'}
                </p>
                <p className="text-green-200 text-xs">Last 30 days</p>
              </div>
              <div className="text-4xl group-hover:scale-110 transition-transform duration-300">📈</div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-emerald-400 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
