import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function MapView({ districts, onDistrictClick }) {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);

  useEffect(() => {
    // Initialize map - India ONLY, NO surrounding areas
    if (!mapInstanceRef.current && mapRef.current) {
      // Strict India bounds (mainland only)
      const indiaBounds = L.latLngBounds(
        [12.0, 72.0],   // Southwest
        [33.5, 92.0]    // Northeast
      );
      
      mapInstanceRef.current = L.map(mapRef.current, {
        maxBounds: indiaBounds,
        maxBoundsViscosity: 1.0,
        minZoom: 4,
        maxZoom: 13
      }).fitBounds(indiaBounds, { padding: [50, 50] });
      
      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18,
        minZoom: 4
      }).addTo(mapInstanceRef.current);
    }

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // India's strict mainland bounds (tighter filtering)
    const indiaBounds = {
      north: 37.0,   // Kashmir
      south: 8.0,    // Tamil Nadu
      east: 97.0,    // Arunachal Pradesh  
      west: 68.0     // Gujarat
    };

    // Add markers for each district (only those within India mainland)
    if (mapInstanceRef.current && districts.length > 0) {
      const validDistricts = districts.filter(d => {
        if (!d.latitude || !d.longitude) return false;
        
        const lat = d.latitude;
        const lon = d.longitude;
        
        // Very strict India mainland bounds
        if (lat < 8.0 || lat > 37.0) return false;
        if (lon < 68.0 || lon > 97.0) return false;
        
        // Exclude ocean areas more precisely
        // Arabian Sea exclusions
        if (lat < 20 && lon < 72) return false;
        if (lat < 15 && lon < 74) return false;
        
        // Bay of Bengal exclusions  
        if (lat < 15 && lon > 80) return false;
        if (lat < 12 && lon > 78) return false;
        
        // Sri Lanka area exclusion
        if (lat < 10 && lon > 79 && lon < 82) return false;
        
        // Additional ocean point exclusions
        if (lat < 18 && lon > 88) return false; // Far east ocean
        if (lat < 16 && lon < 70) return false; // Far west ocean
        
        return true;
      });

      console.log(`Showing ${validDistricts.length} of ${districts.length} districts within India`);

      validDistricts.forEach(district => {
        // Color by risk band (case-insensitive)
        const color = getRiskColor(district.risk_band?.toLowerCase() || 'low');
        
        // Create custom circle marker - sized by risk
        const baseRadius = 2 + (district.risk_score / 50);
        const circle = L.circleMarker([district.latitude, district.longitude], {
          radius: baseRadius,
          fillColor: color,
          color: '#fff',
          weight: 0.5,
          opacity: 0.95,
          fillOpacity: 0.8
        });

        // Popup content
        const popupContent = `
          <div class="text-sm">
            <div class="font-bold text-lg mb-1">${district.district}</div>
            <div class="text-gray-600 mb-2">${district.state}</div>
            <div class="mb-2">
              <span class="font-semibold">Risk Score:</span> 
              <span class="text-lg font-bold" style="color: ${color}">${district.risk_score.toFixed(1)}</span>
            </div>
            <div class="text-xs text-gray-500">
              ${district.population?.toLocaleString() || 0} population
            </div>
          </div>
        `;

        circle.bindPopup(popupContent);
        
        circle.on('click', () => {
          onDistrictClick(district);
        });

        circle.addTo(mapInstanceRef.current);
        markersRef.current.push(circle);
      });
    }

    return () => {
      // Cleanup markers on unmount
      markersRef.current.forEach(marker => marker.remove());
    };
  }, [districts, onDistrictClick]);

  const getRiskColor = (band) => {
    const bandLower = band?.toLowerCase() || 'low';
    switch (bandLower) {
      case 'critical': return '#DC2626';
      case 'high': return '#F59E0B';
      case 'medium': return '#FBBF24';
      case 'low': return '#10B981';
      default: return '#6B7280';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold">District Risk Map</h2>
        <div className="flex gap-4 mt-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#DC2626' }}></div>
            <span>Critical</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F59E0B' }}></div>
            <span>High</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#FBBF24' }}></div>
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#10B981' }}></div>
            <span>Low</span>
          </div>
        </div>
      </div>
      <div 
        ref={mapRef} 
        className="w-full h-96 rounded-b-lg"
        style={{ minHeight: '500px' }}
      />
    </div>
  );
}

export default MapView;