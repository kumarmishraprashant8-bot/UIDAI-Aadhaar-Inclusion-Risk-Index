import { useEffect, useState } from 'react';

function DistrictCard({ district }) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [showSimulation, setShowSimulation] = useState(false);
  const [simulationResult, setSimulationResult] = useState(null);
  const [simulationLoading, setSimulationLoading] = useState(false);

  useEffect(() => {
    setIsAnimating(true);
  }, [district]);

  if (!district) return null;

  const getRiskColor = (band) => {
    switch (band) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-800 border-green-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getRiskBgColor = (band) => {
    switch (band) {
      case 'critical': return 'from-red-50 to-red-100';
      case 'high': return 'from-orange-50 to-orange-100';
      case 'medium': return 'from-yellow-50 to-yellow-100';
      case 'low': return 'from-green-50 to-green-100';
      default: return 'from-gray-50 to-gray-100';
    }
  };

  const formatFeatureName = (name) => {
    return name
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase())
      .replace(/(\d+)d/g, '$1 days');
  };

  const handleSimulate = async () => {
    setSimulationLoading(true);
    try {
      const response = await fetch('http://localhost:8000/simulate_intervention', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          district_id: district.district,
          action: district.recommended_action?.action || 'Continue monitoring',
          intensity: 1.0,
          current_airi_score: district.risk_score,
          citizens_impacted: district.citizens_impacted
        })
      });

      if (response.ok) {
        const result = await response.json();
        setSimulationResult(result);
        setShowSimulation(true);
      } else {
        console.error('Simulation failed:', response.statusText);
      }
    } catch (error) {
      console.error('Simulation error:', error);
    } finally {
      setSimulationLoading(false);
    }
  };

  return (
    <>
      <div className={`bg-white rounded-lg shadow-lg overflow-hidden transform transition-all duration-300 ${isAnimating ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}>
        {/* Header with gradient */}
        <div className={`bg-gradient-to-r ${getRiskBgColor(district.risk_band)} p-6 border-b`}>
          <h2 className="text-3xl font-bold text-gray-900 mb-1">{district.district}</h2>
          <p className="text-gray-700 font-medium mb-4">{district.state}</p>
          
          <div className="flex items-end gap-4">
            <div>
              <div className="text-gray-600 text-sm mb-1">Risk Score</div>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-bold text-gray-900">{district.risk_score}</span>
                <span className="text-gray-500 text-lg">/100</span>
              </div>
            </div>
            <div className={`inline-block px-4 py-2 rounded-full text-sm font-bold border ${getRiskColor(district.risk_band)}`}>
              {district.risk_band?.toUpperCase() || 'UNKNOWN'} RISK
            </div>
          </div>

          <div className="mt-4 text-sm text-gray-700">
            <div className="flex justify-between py-1">
              <span>Estimated Citizens Impacted:</span>
              <span className="font-semibold">{(district.citizens_impacted || 0).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Risk Drivers */}
        <div className="p-6 border-b bg-gray-50">
          <h3 className="text-lg font-semibold mb-4 text-gray-900">Top Risk Drivers</h3>
          <div className="space-y-4">
            {district.shap_drivers && district.shap_drivers.slice(0, 3).map((driver, idx) => (
              <div key={idx} className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex justify-between items-baseline mb-2">
                  <span className="font-medium text-gray-900">{idx + 1}. {formatFeatureName(driver.feature)}</span>
                  <span className={`text-sm font-bold ${driver.shap_value > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {driver.shap_value > 0 ? '+' : ''}{(driver.shap_value * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-500 ${driver.shap_value > 0 ? 'bg-red-500' : 'bg-green-500'}`}
                    style={{ width: `${Math.min(Math.abs(driver.shap_value) * 100, 100)}%` }}
                  />
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  Current value: {driver.feature_value?.toFixed(3)}
                </div>
              </div>
            ))}
          </div>

          {district.explanation && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
              <p className="text-sm text-blue-900">
                <span className="font-bold block mb-1">💡 Key Insight:</span>
                {district.explanation}
              </p>
            </div>
          )}
        </div>

        {/* Recommended Action */}
        {district.recommended_action && (
          <div className="p-6 bg-gradient-to-r from-indigo-50 to-purple-50">
            <h3 className="text-lg font-semibold mb-4 text-gray-900">Recommended Action</h3>
            <div className="bg-white rounded-lg p-5 border-2 border-indigo-200 shadow-md">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                  <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-lg text-indigo-900 mb-3">
                    {district.recommended_action.action}
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm mb-4">
                    <div className="bg-indigo-50 rounded p-3">
                      <span className="text-indigo-700 block text-xs font-semibold mb-1">Expected Impact</span>
                      <span className="font-bold text-indigo-900">
                        {district.recommended_action.expected_impact}
                      </span>
                    </div>
                    <div className="bg-purple-50 rounded p-3">
                      <span className="text-purple-700 block text-xs font-semibold mb-1">Cost Band</span>
                      <span className="font-bold text-purple-900">
                        {district.recommended_action.cost_band}
                      </span>
                    </div>
                    <div className={`rounded p-3 ${
                      district.recommended_action.priority === 'High' ? 'bg-red-50' :
                      district.recommended_action.priority === 'Medium' ? 'bg-yellow-50' :
                      'bg-green-50'
                    }`}>
                      <span className={`block text-xs font-semibold mb-1 ${
                        district.recommended_action.priority === 'High' ? 'text-red-700' :
                        district.recommended_action.priority === 'Medium' ? 'text-yellow-700' :
                        'text-green-700'
                      }`}>Priority</span>
                      <span className={`font-bold ${
                        district.recommended_action.priority === 'High' ? 'text-red-900' :
                        district.recommended_action.priority === 'Medium' ? 'text-yellow-900' :
                        'text-green-900'
                      }`}>
                        {district.recommended_action.priority}
                      </span>
                    </div>
                  </div>

                  {/* Simulate Button */}
                  <button
                    onClick={handleSimulate}
                    disabled={simulationLoading}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                  >
                    {simulationLoading ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Simulating Impact...
                      </span>
                    ) : (
                      '🎯 Simulate Impact & Cost'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Simulation Modal */}
      {showSimulation && simulationResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Intervention Impact Simulation</h3>
                  <p className="text-gray-600 mt-1">{district.district}, {district.state}</p>
                </div>
                <button
                  onClick={() => setShowSimulation(false)}
                  className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-white transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Before/After Comparison */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-red-50 rounded-lg p-6 border-2 border-red-200">
                  <h4 className="font-bold text-red-800 mb-4 flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
                    </svg>
                    Before Intervention
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-red-700">AIRI Score:</span>
                      <span className="font-bold text-red-800 text-xl">{simulationResult.before?.airi_score}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-red-700">Citizens Impacted:</span>
                      <span className="font-bold text-red-800">{simulationResult.before?.citizens_impacted?.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-red-700">Risk Level:</span>
                      <span className="font-bold text-red-800">{simulationResult.before?.risk_level}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 rounded-lg p-6 border-2 border-green-200">
                  <h4 className="font-bold text-green-800 mb-4 flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    After Intervention
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-green-700">AIRI Score:</span>
                      <span className="font-bold text-green-800 text-xl">{simulationResult.after?.airi_score}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-700">Citizens Impacted:</span>
                      <span className="font-bold text-green-800">{simulationResult.after?.citizens_impacted?.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-700">Risk Level:</span>
                      <span className="font-bold text-green-800">{simulationResult.after?.risk_level}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Impact Summary */}
              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h4 className="font-bold text-blue-800 mb-4 flex items-center">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                  Impact Summary
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-800">{simulationResult.impact?.citizens_protected?.toLocaleString()}</div>
                    <div className="text-sm text-blue-700">Citizens Protected</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-800">-{simulationResult.impact?.airi_score_reduction}</div>
                    <div className="text-sm text-blue-700">AIRI Reduction</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-800">{simulationResult.impact?.relative_improvement}</div>
                    <div className="text-sm text-blue-700">Improvement</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-800">{simulationResult.implementation_days}</div>
                    <div className="text-sm text-blue-700">Days to Implement</div>
                  </div>
                </div>
              </div>

              {/* Cost Analysis */}
              <div className="bg-yellow-50 rounded-lg p-6 border-2 border-yellow-200">
                <h4 className="font-bold text-yellow-800 mb-4 flex items-center">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                  Cost Analysis
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-800">₹{simulationResult.cost?.total_cost_inr?.toLocaleString()}</div>
                    <div className="text-sm text-yellow-700">Total Cost</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-800">₹{simulationResult.cost?.cost_per_citizen_protected}</div>
                    <div className="text-sm text-yellow-700">Cost per Citizen</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-800">{simulationResult.cost?.cost_effectiveness}</div>
                    <div className="text-sm text-yellow-700">Effectiveness</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-800">₹{simulationResult.cost?.budget_category?.toLocaleString()}</div>
                    <div className="text-sm text-yellow-700">Budget Category</div>
                  </div>
                </div>
              </div>

              {/* Confidence Intervals */}
              <div className="bg-gray-50 rounded-lg p-6 border-2 border-gray-200">
                <h4 className="font-bold text-gray-800 mb-4 flex items-center">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  Confidence Intervals
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white rounded p-4 border">
                    <div className="font-semibold text-gray-800 mb-2">Conservative Scenario (50%)</div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>Citizens Protected: {simulationResult.confidence_intervals?.conservative?.citizens_protected?.toLocaleString()}</div>
                      <div>AIRI Score: {simulationResult.confidence_intervals?.conservative?.airi_score}</div>
                    </div>
                  </div>
                  <div className="bg-white rounded p-4 border">
                    <div className="font-semibold text-gray-800 mb-2">Optimistic Scenario (150%)</div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>Citizens Protected: {simulationResult.confidence_intervals?.optimistic?.citizens_protected?.toLocaleString()}</div>
                      <div>AIRI Score: {simulationResult.confidence_intervals?.optimistic?.airi_score}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 bg-gray-50">
              <button
                onClick={() => setShowSimulation(false)}
                className="w-full bg-gradient-to-r from-gray-600 to-gray-700 text-white px-4 py-3 rounded-lg font-semibold hover:from-gray-700 hover:to-gray-800 transition-colors"
              >
                Close Simulation
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default DistrictCard;