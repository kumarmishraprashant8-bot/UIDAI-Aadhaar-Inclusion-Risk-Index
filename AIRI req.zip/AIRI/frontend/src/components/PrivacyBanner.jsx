import React from 'react';

function PrivacyBanner() {
  return (
    <div className="bg-indigo-900 text-white py-3 px-4">
      <div className="container mx-auto flex items-center gap-3">
        <svg className="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
        </svg>
        <div className="text-sm">
          <strong>Privacy Assured:</strong> This demo uses synthetic data only. No real Aadhaar numbers, biometric data, or personally identifiable information is displayed. All outputs are aggregated at district level.
        </div>
      </div>
    </div>
  );
}

export default PrivacyBanner;
