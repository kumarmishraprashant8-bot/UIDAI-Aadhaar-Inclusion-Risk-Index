# AIRI Demo Script - 3 Minutes

## 🎯 Demo Overview
**Audience**: UIDAI Judges, Technical Evaluators  
**Duration**: 3 minutes  
**Objective**: Demonstrate AIRI's predictive + prescriptive capabilities  
**Key Message**: "AIRI transforms Aadhaar enrollment data into actionable insights that protect citizens from exclusion"

---

## 🚀 Demo Flow

### **Opening (30 seconds)**
*[Screen: AIRI Dashboard Loading]*

**"Good morning! I'm excited to show you AIRI - the Aadhaar Inclusion Risk Index. AIRI is India's first predictive system that identifies districts at risk of Aadhaar enrollment exclusion before citizens are affected."**

*[Click: Enter Dashboard]*

**"What you're seeing is 100% synthetic data - no real Aadhaar numbers or biometric data. AIRI is privacy-first by design."**

---

### **Dashboard Overview (45 seconds)**
*[Screen: Main Dashboard with KPIs and Map]*

**"AIRI monitors 100 districts in real-time. Here's what judges should notice:"**

*[Point to KPI cards]*
- **"National AIRI Score: 42 - this means moderate risk overall"**
- **"18 high-risk districts need immediate attention"**  
- **"127,000 citizens are currently at risk of enrollment exclusion"**

*[Point to map]*
**"The map shows risk levels: Red is critical, orange is high, yellow is medium, green is low. Each dot represents a district with real-time risk scoring."**

---

### **District Deep-Dive (60 seconds)**
*[Click: Select a critical risk district (red dot)]*

**"Let me show you what makes AIRI powerful. I'm clicking on Patna - a critical risk district with AIRI score 78."**

*[Screen: District detail panel opens]*

**"AIRI doesn't just give you a number. It explains WHY:"**

*[Point to risk drivers]*
- **"Top driver: High biometric failure rate - 23% impact"**
- **"Second: Device performance inconsistency - 18% impact"**  
- **"Third: Processing time delays - 15% impact"**

*[Point to explanation]*
**"AIRI translates complex ML into plain English: 'High biometric failure rate and device performance inconsistency are driving exclusion risk.'"**

---

### **Prescriptive Action (45 seconds)**
*[Scroll to recommended action]*

**"But AIRI goes beyond prediction - it's prescriptive. For Patna, AIRI recommends:"**

*[Read action card]*
**"Deploy mobile enrollment camp immediately within 7 days"**
- **"Expected impact: 15-25% reduction in exclusion risk"**
- **"Cost band: Medium, Priority: High"**

*[Click: Simulate Impact button]*
**"Now watch this - AIRI can simulate the intervention impact before you spend a rupee."**

---

### **Impact Simulation (30 seconds)**
*[Screen: Simulation modal opens]*

**"The simulation shows:"**
- **"Before: 78 AIRI score, 45,000 citizens at risk"**
- **"After: 59 AIRI score, 34,000 citizens at risk"**  
- **"Impact: 11,000 citizens protected for ₹6.75 lakhs"**
- **"Cost effectiveness: ₹61 per citizen - that's excellent ROI"**

*[Point to confidence intervals]*
**"AIRI even provides conservative and optimistic scenarios for budget planning."**

---

### **Closing (30 seconds)**
*[Close modal, return to dashboard]*

**"That's AIRI in 3 minutes:"**
1. **"PREDICTS exclusion risk 7-30 days in advance"**
2. **"EXPLAINS the drivers in human language"**  
3. **"PRESCRIBES specific UIDAI interventions"**
4. **"SIMULATES impact and cost before implementation"**

**"AIRI is privacy-compliant, judge-ready, and can protect millions of citizens from Aadhaar exclusion. Thank you!"**

---

## 🎯 Key Talking Points

### **Technical Excellence**
- "Machine learning with 75%+ precision at top 100 predictions"
- "SHAP explainability - no black box decisions"
- "Real-time scoring with <100ms API response"
- "Calibrated probabilities with confidence intervals"

### **Privacy Leadership**  
- "Zero PII storage - no Aadhaar numbers or biometrics"
- "District-level aggregation only"
- "Cryptographic hashing for evidence packets"
- "UIDAI regulation compliant"

### **Actionable Impact**
- "4 mapped interventions: mobile camps, device audits, extended hours, monitoring"
- "Cost estimates: ₹15-61 per citizen protected"
- "15-25% risk reduction in 7-30 days"
- "Pilot-ready with ₹2.5L budget for 4 districts"

### **Judge Appeal**
- "Addresses real UIDAI operational challenges"
- "Measurable ROI and cost-effectiveness"
- "Scalable to 700+ districts nationwide"
- "Privacy-first design for public trust"

---

## 🎬 Demo Preparation Checklist

### **Technical Setup**
- [ ] Backend running on localhost:8000
- [ ] Frontend running on localhost:5173  
- [ ] Demo data loaded (100 districts)
- [ ] All API endpoints responding
- [ ] Simulation functionality tested

### **Browser Setup**
- [ ] Chrome/Firefox with good performance
- [ ] Zoom level at 100% for optimal display
- [ ] Bookmarks cleared from view
- [ ] Full-screen mode ready (F11)
- [ ] Network connection stable

### **Presentation Setup**
- [ ] Screen sharing tested and optimized
- [ ] Audio levels checked
- [ ] Backup demo video ready
- [ ] Timer set for 3 minutes
- [ ] Questions and answers prepared

### **Content Rehearsal**
- [ ] Script memorized and natural
- [ ] Click sequence practiced 5+ times
- [ ] Timing optimized (30s per section)
- [ ] Backup talking points ready
- [ ] Technical terms explained simply

---

## 🔧 Troubleshooting

### **If API is slow**
- "AIRI typically responds in under 100ms - this demo environment is running locally"
- Continue with cached data or pre-loaded screenshots

### **If simulation fails**
- "Let me show you a pre-computed simulation result"
- Have backup simulation screenshots ready

### **If map doesn't load**
- "The risk scores are the key insight - let me show you the district details directly"
- Focus on the district card and risk drivers

### **If questions arise**
- **Privacy**: "AIRI uses only aggregated district statistics - no individual data"
- **Accuracy**: "75%+ precision at top 100 predictions, validated on synthetic data"
- **Cost**: "₹15-61 per citizen protected, with 2-week pilot at ₹2.5L total"
- **Scale**: "Designed for 700+ districts, cloud-ready architecture"

---

## 📊 Demo Success Metrics

### **Engagement Indicators**
- Judges ask follow-up questions about technical approach
- Interest in pilot implementation details
- Questions about scalability and cost
- Requests for additional demonstrations

### **Technical Credibility**
- No technical failures during demo
- Smooth transitions between screens
- Clear explanation of ML concepts
- Confident handling of technical questions

### **Business Impact**
- Clear understanding of ROI and cost-effectiveness
- Recognition of operational value for UIDAI
- Appreciation for privacy-first design
- Interest in next steps and implementation

---

**Demo Version**: 1.0  
**Last Rehearsal**: January 20, 2025  
**Presenter**: [Name]  
**Backup Presenter**: [Name]

---

*This script ensures a compelling, technically sound, and time-efficient demonstration of AIRI's capabilities to UIDAI judges and evaluators.*