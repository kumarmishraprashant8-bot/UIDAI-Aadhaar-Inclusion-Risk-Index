"""
scripts/generate_synthetic_data.py
Generate plausible synthetic district-level data for AIRI demo
"""

import pandas as pd
import numpy as np
from pathlib import Path


# Real Indian states and representative districts
INDIAN_DISTRICTS = [
    ("Uttar Pradesh", "Lucknow", 26.8467, 80.9462),
    ("Uttar Pradesh", "Gorakhpur", 26.7606, 83.3732),
    ("Uttar Pradesh", "Agra", 27.1767, 78.0081),
    ("Maharashtra", "Mumbai", 19.0760, 72.8777),
    ("Maharashtra", "Pune", 18.5204, 73.8567),
    ("Maharashtra", "Nagpur", 21.1458, 79.0882),
    ("Bihar", "Patna", 25.5941, 85.1376),
    ("Bihar", "Gaya", 24.7955, 84.9994),
    ("Bihar", "Muzaffarpur", 26.1209, 85.3647),
    ("West Bengal", "Kolkata", 22.5726, 88.3639),
    ("West Bengal", "Darjeeling", 27.0360, 88.2627),
    ("Madhya Pradesh", "Bhopal", 23.2599, 77.4126),
    ("Madhya Pradesh", "Indore", 22.7196, 75.8577),
    ("Tamil Nadu", "Chennai", 13.0827, 80.2707),
    ("Tamil Nadu", "Coimbatore", 11.0168, 76.9558),
    ("Rajasthan", "Jaipur", 26.9124, 75.7873),
    ("Rajasthan", "Jodhpur", 26.2389, 73.0243),
    ("Karnataka", "Bengaluru", 12.9716, 77.5946),
    ("Karnataka", "Mysuru", 12.2958, 76.6394),
    ("Gujarat", "Ahmedabad", 23.0225, 72.5714),
    ("Gujarat", "Surat", 21.1702, 72.8311),
    ("Andhra Pradesh", "Visakhapatnam", 17.6868, 83.2185),
    ("Andhra Pradesh", "Vijayawada", 16.5062, 80.6480),
    ("Telangana", "Hyderabad", 17.3850, 78.4867),
    ("Kerala", "Thiruvananthapuram", 8.5241, 76.9366),
    ("Assam", "Guwahati", 26.1445, 91.7362),
    ("Punjab", "Ludhiana", 30.9010, 75.8573),
    ("Haryana", "Gurugram", 28.4595, 77.0266),
    ("Jharkhand", "Ranchi", 23.3441, 85.3096),
    ("Odisha", "Bhubaneswar", 20.2961, 85.8245),
    ("Chhattisgarh", "Raipur", 21.2514, 81.6296),
    ("Delhi", "New Delhi", 28.6139, 77.2090),
]


def generate_synthetic_districts(n_districts: int = 100, output_path: str = "data/synthetic_districts.csv"):
    """
    Generate synthetic district-level aggregated data.
    
    Args:
        n_districts: Number of districts to generate
        output_path: Output CSV path
    """
    np.random.seed(42)
    
    # Sample districts (with replacement if needed)
    if n_districts > len(INDIAN_DISTRICTS):
        sampled = INDIAN_DISTRICTS * (n_districts // len(INDIAN_DISTRICTS) + 1)
        sampled = sampled[:n_districts]
    else:
        sampled = np.random.choice(len(INDIAN_DISTRICTS), n_districts, replace=False)
        sampled = [INDIAN_DISTRICTS[i] for i in sampled]
    
    data = []
    
    # India bounds (mainland only)
    lat_min, lat_max = 12.0, 33.5
    lon_min, lon_max = 72.0, 92.0
    
    for idx, (state, district, lat, lon) in enumerate(sampled):
        # Add small random variation to coordinates for duplicates
        # (to avoid all duplicates appearing at exact same spot)
        lat_variation = np.random.uniform(-0.10, 0.10)  # ~10km variation
        lon_variation = np.random.uniform(-0.10, 0.10)
        lat = np.clip(lat + lat_variation, lat_min, lat_max)
        lon = np.clip(lon + lon_variation, lon_min, lon_max)
        
        # Base event volume (varies by district urbanization)
        base_volume = np.random.randint(500, 5000)
        
        # Time windows
        events_7d = max(0, int(np.random.normal(base_volume * 0.2, base_volume * 0.05)))
        events_14d = max(0, int(np.random.normal(base_volume * 0.4, base_volume * 0.08)))
        events_30d = max(0, int(np.random.normal(base_volume, base_volume * 0.15)))
        
        # Failure rates (some districts have higher issues)
        rejected_base_rate = np.random.uniform(0.02, 0.15)
        rejected_60d = max(0, int(np.random.poisson(events_30d * 2 * rejected_base_rate)))
        
        biometric_fail_rate = np.random.uniform(0.01, 0.10)
        biometric_fail_60d = max(0, int(np.random.poisson(events_30d * 2 * biometric_fail_rate)))
        
        success_90d = max(0, int(events_30d * 3 * (1 - rejected_base_rate - biometric_fail_rate) + np.random.normal(0, 50)))
        
        # Device/center stats
        n_devices = np.random.randint(5, 50)
        device_mean = events_30d / n_devices
        device_std = device_mean * np.random.uniform(0.3, 1.0)
        
        n_centers = np.random.randint(3, 20)
        center_mean = events_30d / n_centers
        center_std = center_mean * np.random.uniform(0.3, 1.2)
        
        # Demographics
        total_pop = np.random.randint(50000, 500000)
        age_60plus = int(total_pop * np.random.uniform(0.05, 0.15))
        age_0_17 = int(total_pop * np.random.uniform(0.20, 0.40))
        
        # Mobile camps
        mobile_camp_events = max(0, int(np.random.poisson(events_30d * 0.1)))
        
        # Processing time
        proc_time_median = np.random.uniform(40, 120)
        proc_time_p95 = proc_time_median * np.random.uniform(1.5, 3.5)
        
        # Repeat updates
        repeat_update_count = max(0, int(np.random.poisson(events_30d * 0.05)))
        
        data.append({
            'state': state,
            'district': district,
            'latitude': lat,
            'longitude': lon,
            'event_count_7d': events_7d,
            'event_count_14d': events_14d,
            'event_count_30d': events_30d,
            'rejected_count_60d': rejected_60d,
            'biometric_fail_count_60d': biometric_fail_60d,
            'success_count_90d': success_90d,
            'device_event_mean': device_mean,
            'device_event_std': device_std,
            'center_event_mean': center_mean,
            'center_event_std': center_std,
            'age_60plus_count': age_60plus,
            'age_0_17_count': age_0_17,
            'total_population': total_pop,
            'mobile_camp_events': mobile_camp_events,
            'processing_time_median': proc_time_median,
            'processing_time_p95': proc_time_p95,
            'repeat_update_count': repeat_update_count
        })
    
    df = pd.DataFrame(data)
    
    # Save
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    
    print(f"Generated {len(df)} synthetic districts")
    print(f"Saved to {output_path}")
    print(f"\nSample:\n{df.head()}")
    
    return df


if __name__ == '__main__':
    generate_synthetic_districts(n_districts=100)