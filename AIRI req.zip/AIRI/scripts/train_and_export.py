#!/usr/bin/env python3
"""
train_and_export.py
Production training script for AIRI.
Trains LightGBM model, computes SHAP values, saves model.joblib and feature_metadata.json
"""

import pandas as pd
import numpy as np
import lightgbm as lgb
import joblib
import json
import shap
from pathlib import Path
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc
from typing import Dict, List, Tuple
import warnings
warnings.filterwarnings('ignore')


def create_proxy_labels(df: pd.DataFrame) -> pd.Series:
    """
    Create defensible proxy labels for 'exclusion risk'.
    Rule: 3+ rejected/failed outcomes in 60 days OR 2+ biometric failures + no success in 90 days.
    
    Args:
        df: District-level aggregated data with columns: district, date, rejected_count_60d, 
            biometric_fail_count_60d, success_count_90d
    
    Returns:
        Binary series (1 = high risk, 0 = normal)
    """
    labels = (
        (df['rejected_count_60d'] >= 3) | 
        ((df['biometric_fail_count_60d'] >= 2) & (df['success_count_90d'] == 0))
    ).astype(int)
    
    print(f"Label distribution: {labels.value_counts().to_dict()}")
    print(f"Positive rate: {labels.mean():.3f}")
    return labels


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Engineer time-window aggregated features at district level.
    
    Features:
    - Counts and z-scores for 7/14/30 day windows
    - Device/center burstiness (Gini coefficient proxy)
    - Demographic composition (% elderly, % children)
    - Mobile camp coverage proxy
    - Processing time anomalies (95th percentile / median)
    """
    # Time window counts
    for window in [7, 14, 30]:
        df[f'total_events_{window}d'] = df[f'event_count_{window}d']
        df[f'rejected_rate_{window}d'] = df[f'rejected_count_{window}d'] / (df[f'total_events_{window}d'] + 1)
        df[f'biometric_fail_rate_{window}d'] = df[f'biometric_fail_count_{window}d'] / (df[f'total_events_{window}d'] + 1)
        
        # Z-score vs baseline (assume baseline computed separately)
        baseline_mean = df[f'total_events_{window}d'].mean()
        baseline_std = df[f'total_events_{window}d'].std()
        df[f'event_zscore_{window}d'] = (df[f'total_events_{window}d'] - baseline_mean) / (baseline_std + 1e-6)
    
    # Device/center burstiness (simplified: coefficient of variation)
    df['device_burstiness'] = df['device_event_std'] / (df['device_event_mean'] + 1)
    df['center_burstiness'] = df['center_event_std'] / (df['center_event_mean'] + 1)
    
    # Demographics
    df['pct_elderly'] = df['age_60plus_count'] / (df['total_population'] + 1)
    df['pct_children'] = df['age_0_17_count'] / (df['total_population'] + 1)
    
    # Mobile camp coverage (events per capita)
    df['mobile_camp_coverage'] = df['mobile_camp_events'] / (df['total_population'] + 1)
    
    # Processing time anomaly
    df['processing_time_anomaly'] = df['processing_time_p95'] / (df['processing_time_median'] + 1)
    
    # Repeat update rate
    df['repeat_update_rate'] = df['repeat_update_count'] / (df['total_events_30d'] + 1)
    
    return df


def precision_at_k(y_true: np.ndarray, y_score: np.ndarray, k: int = 50) -> float:
    """Compute Precision@K"""
    top_k_idx = np.argsort(y_score)[-k:]
    return y_true[top_k_idx].mean()


def train_model(X: pd.DataFrame, y: pd.Series) -> Tuple[lgb.Booster, Dict]:
    """
    Train LightGBM with stratified CV and early stopping.
    
    Returns:
        Trained model and evaluation metrics dict
    """
    params = {
        'objective': 'binary',
        'metric': 'auc',
        'num_boost_round': 1000,
        'learning_rate': 0.05,
        'max_depth': 6,
        'num_leaves': 31,
        'min_data_in_leaf': 20,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1
    }
    
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    oof_preds = np.zeros(len(y))
    metrics = {'auc': [], 'pr_auc': [], 'precision_at_50': []}
    
    for fold, (train_idx, val_idx) in enumerate(cv.split(X, y)):
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
        
        train_data = lgb.Dataset(X_train, label=y_train)
        val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)
        
        model = lgb.train(
            params,
            train_data,
            valid_sets=[val_data],
            callbacks=[lgb.early_stopping(stopping_rounds=50), lgb.log_evaluation(50)]
        )
        
        oof_preds[val_idx] = model.predict(X_val)
        
        # Metrics
        auc_score = roc_auc_score(y_val, oof_preds[val_idx])
        precision, recall, _ = precision_recall_curve(y_val, oof_preds[val_idx])
        pr_auc = auc(recall, precision)
        p_at_50 = precision_at_k(y_val.values, oof_preds[val_idx], k=min(50, len(y_val)))
        
        metrics['auc'].append(auc_score)
        metrics['pr_auc'].append(pr_auc)
        metrics['precision_at_50'].append(p_at_50)
        
        print(f"Fold {fold+1}: AUC={auc_score:.4f}, PR-AUC={pr_auc:.4f}, P@50={p_at_50:.4f}")
    
    # Train final model on full data
    train_data = lgb.Dataset(X, label=y)
    final_model = lgb.train(params, train_data, num_boost_round=params['num_boost_round'])
    
    # Average metrics
    avg_metrics = {k: np.mean(v) for k, v in metrics.items()}
    print(f"\nAverage Metrics: {avg_metrics}")
    
    return final_model, avg_metrics


def compute_shap_importance(model: lgb.Booster, X: pd.DataFrame) -> Dict:
    """
    Compute global SHAP feature importance.
    
    Returns:
        Dict mapping feature names to mean absolute SHAP values
    """
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    # For binary classification, shap_values is array
    if isinstance(shap_values, list):
        shap_values = shap_values[1]  # positive class
    
    importance = pd.DataFrame({
        'feature': X.columns,
        'importance': np.abs(shap_values).mean(axis=0)
    }).sort_values('importance', ascending=False)
    
    return importance.set_index('feature')['importance'].to_dict()


def main():
    """Main training pipeline"""
    # 1. Load data (replace with actual data loading)
    # For demo, create synthetic data
    print("Loading data...")
    # df = pd.read_csv('data/district_aggregated.csv')
    
    # Synthetic placeholder
    np.random.seed(42)
    n_districts = 500
    df = pd.DataFrame({
        'district': [f'District_{i}' for i in range(n_districts)],
        'date': pd.date_range('2024-01-01', periods=n_districts, freq='D'),
        'event_count_7d': np.random.poisson(100, n_districts),
        'event_count_14d': np.random.poisson(200, n_districts),
        'event_count_30d': np.random.poisson(400, n_districts),
        'rejected_count_60d': np.random.poisson(5, n_districts),
        'biometric_fail_count_60d': np.random.poisson(3, n_districts),
        'success_count_90d': np.random.poisson(300, n_districts),
        'device_event_mean': np.random.uniform(10, 50, n_districts),
        'device_event_std': np.random.uniform(5, 20, n_districts),
        'center_event_mean': np.random.uniform(20, 100, n_districts),
        'center_event_std': np.random.uniform(10, 40, n_districts),
        'age_60plus_count': np.random.randint(0, 5000, n_districts),
        'age_0_17_count': np.random.randint(0, 10000, n_districts),
        'total_population': np.random.randint(10000, 100000, n_districts),
        'mobile_camp_events': np.random.poisson(20, n_districts),
        'processing_time_median': np.random.uniform(30, 120, n_districts),
        'processing_time_p95': np.random.uniform(60, 300, n_districts),
        'repeat_update_count': np.random.poisson(10, n_districts)
    })
    
    # 2. Create labels
    print("Creating proxy labels...")
    y = create_proxy_labels(df)
    
    # 3. Feature engineering
    print("Engineering features...")
    df = engineer_features(df)
    
    # 4. Select features
    feature_cols = [c for c in df.columns if c not in ['district', 'date', 'rejected_count_60d', 
                                                         'biometric_fail_count_60d', 'success_count_90d']]
    X = df[feature_cols].fillna(0)
    
    # 5. Train model
    print("Training LightGBM model...")
    model, metrics = train_model(X, y)
    
    # 6. SHAP importance
    print("Computing SHAP importance...")
    shap_importance = compute_shap_importance(model, X.sample(min(500, len(X)), random_state=42))
    
    # 7. Save artifacts
    print("Saving model and metadata...")
    Path('models').mkdir(exist_ok=True)
    
    joblib.dump(model, 'models/model.joblib')
    
    metadata = {
        'features': feature_cols,
        'metrics': metrics,
        'shap_importance': shap_importance,
        'label_rule': 'rejected_count_60d >= 3 OR (biometric_fail_count_60d >= 2 AND success_count_90d == 0)',
        'trained_date': pd.Timestamp.now().isoformat()
    }
    
    with open('models/feature_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("Training complete!")
    print(f"Model saved to models/model.joblib")
    print(f"Metadata saved to models/feature_metadata.json")
    print(f"Final Metrics: {metrics}")


if __name__ == '__main__':
    main()