"""
scripts/validate.py
System validation suite for AIRI
"""

import sys
import json
import requests
import pandas as pd
from pathlib import Path
import joblib
import numpy as np
from typing import Dict, List, Tuple


def validate_backend_health() -> Tuple[bool, str]:
    """Test backend health endpoint"""
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "healthy":
                return True, "✅ Backend health check passed"
            else:
                return False, f"❌ Backend unhealthy: {data}"
        else:
            return False, f"❌ Backend health check failed: {response.status_code}"
    except Exception as e:
        return False, f"❌ Backend connection failed: {e}"


def validate_model_files() -> Tuple[bool, str]:
    """Validate model and metadata files exist and are loadable"""
    try:
        model_path = Path("models/model.joblib")
        metadata_path = Path("models/feature_metadata.json")
        
        if not model_path.exists():
            return False, "❌ Model file missing: models/model.joblib"
        
        if not metadata_path.exists():
            return False, "❌ Metadata file missing: models/feature_metadata.json"
        
        # Try loading model
        model = joblib.load(model_path)
        
        # Try loading metadata
        with open(metadata_path) as f:
            metadata = json.load(f)
        
        # Validate metadata structure
        required_keys = ['features', 'metrics', 'training_date']
        missing_keys = [key for key in required_keys if key not in metadata]
        
        if missing_keys:
            return False, f"❌ Metadata missing keys: {missing_keys}"
        
        return True, f"✅ Model files valid (features: {len(metadata['features'])})"
    
    except Exception as e:
        return False, f"❌ Model validation failed: {e}"


def validate_synthetic_data() -> Tuple[bool, str]:
    """Validate synthetic data files"""
    try:
        districts_path = Path("data/synthetic_districts.csv")
        scores_path = Path("data/demo_scores.json")
        
        if not districts_path.exists():
            return False, "❌ Synthetic districts file missing"
        
        if not scores_path.exists():
            return False, "❌ Demo scores file missing"
        
        # Load and validate districts data
        df = pd.read_csv(districts_path)
        
        required_cols = ['district', 'state', 'latitude', 'longitude', 'event_count_30d']
        missing_cols = [col for col in required_cols if col not in df.columns]
        
        if missing_cols:
            return False, f"❌ Districts data missing columns: {missing_cols}"
        
        # Validate geographic bounds (India)
        lat_valid = (df['latitude'] >= 8.0) & (df['latitude'] <= 37.0)
        lon_valid = (df['longitude'] >= 68.0) & (df['longitude'] <= 97.0)
        
        if not lat_valid.all() or not lon_valid.all():
            return False, "❌ Geographic coordinates outside India bounds"
        
        # Load and validate scores
        with open(scores_path) as f:
            scores = json.load(f)
        
        if not isinstance(scores, list) or len(scores) == 0:
            return False, "❌ Demo scores invalid format"
        
        return True, f"✅ Synthetic data valid ({len(df)} districts, {len(scores)} scores)"
    
    except Exception as e:
        return False, f"❌ Data validation failed: {e}"


def validate_airi_scoring() -> Tuple[bool, str]:
    """Test AIRI scoring endpoint"""
    try:
        response = requests.get("http://localhost:8000/scores/latest?limit=5", timeout=10)
        
        if response.status_code != 200:
            return False, f"❌ Scoring endpoint failed: {response.status_code}"
        
        scores = response.json()
        
        if not isinstance(scores, list) or len(scores) == 0:
            return False, "❌ No scores returned"
        
        # Validate score structure
        sample_score = scores[0]
        required_fields = ['district', 'risk_score', 'risk_band', 'explanation']
        missing_fields = [field for field in required_fields if field not in sample_score]
        
        if missing_fields:
            return False, f"❌ Score missing fields: {missing_fields}"
        
        # Validate AIRI score range
        for score in scores:
            airi_score = score.get('risk_score', -1)
            if not (0 <= airi_score <= 100):
                return False, f"❌ Invalid AIRI score: {airi_score} (must be 0-100)"
        
        return True, f"✅ AIRI scoring valid ({len(scores)} scores, range 0-100)"
    
    except Exception as e:
        return False, f"❌ Scoring validation failed: {e}"


def validate_simulation_endpoint() -> Tuple[bool, str]:
    """Test intervention simulation endpoint"""
    try:
        # Get a sample district
        response = requests.get("http://localhost:8000/scores/latest?limit=1", timeout=5)
        if response.status_code != 200:
            return False, "❌ Cannot get sample district for simulation test"
        
        scores = response.json()
        if not scores:
            return False, "❌ No districts available for simulation test"
        
        sample_district = scores[0]
        
        # Test simulation
        simulation_request = {
            "district_id": sample_district['district'],
            "action": "Deploy mobile enrollment camp",
            "intensity": 1.0,
            "current_airi_score": sample_district['risk_score'],
            "citizens_impacted": sample_district.get('citizens_impacted', 10000)
        }
        
        response = requests.post(
            "http://localhost:8000/simulate_intervention",
            json=simulation_request,
            timeout=10
        )
        
        if response.status_code != 200:
            return False, f"❌ Simulation endpoint failed: {response.status_code}"
        
        result = response.json()
        
        # Validate simulation structure
        required_sections = ['before', 'after', 'impact', 'cost']
        missing_sections = [section for section in required_sections if section not in result]
        
        if missing_sections:
            return False, f"❌ Simulation missing sections: {missing_sections}"
        
        # Validate impact logic
        before_score = result['before']['airi_score']
        after_score = result['after']['airi_score']
        
        if after_score > before_score:
            return False, f"❌ Simulation logic error: score increased ({before_score} → {after_score})"
        
        return True, f"✅ Simulation valid (impact: {before_score} → {after_score})"
    
    except Exception as e:
        return False, f"❌ Simulation validation failed: {e}"


def validate_privacy_compliance() -> Tuple[bool, str]:
    """Check privacy compliance"""
    try:
        # Check that no PII files exist
        pii_patterns = [
            "**/*aadhaar*",
            "**/*biometric*",
            "**/*fingerprint*",
            "**/*iris*",
            "**/*photo*"
        ]
        
        pii_files = []
        for pattern in pii_patterns:
            pii_files.extend(Path(".").glob(pattern))
        
        if pii_files:
            return False, f"❌ Potential PII files found: {[str(f) for f in pii_files]}"
        
        # Check synthetic data has no real identifiers
        districts_path = Path("data/synthetic_districts.csv")
        if districts_path.exists():
            df = pd.read_csv(districts_path)
            
            # Check for suspicious patterns
            if 'aadhaar' in ' '.join(df.columns).lower():
                return False, "❌ Aadhaar column found in synthetic data"
            
            if any(col.lower().startswith('bio') for col in df.columns):
                return False, "❌ Biometric columns found in synthetic data"
        
        return True, "✅ Privacy compliance validated (no PII detected)"
    
    except Exception as e:
        return False, f"❌ Privacy validation failed: {e}"


def validate_frontend_accessibility() -> Tuple[bool, str]:
    """Test frontend accessibility (basic check)"""
    try:
        # Try to reach frontend
        response = requests.get("http://localhost:5173", timeout=5)
        
        if response.status_code == 200:
            # Basic HTML validation
            html = response.text.lower()
            
            # Check for essential elements
            if 'airi' not in html:
                return False, "❌ Frontend missing AIRI branding"
            
            if 'privacy' not in html:
                return False, "❌ Frontend missing privacy notice"
            
            return True, "✅ Frontend accessible and branded"
        else:
            return False, f"❌ Frontend not accessible: {response.status_code}"
    
    except Exception as e:
        return False, f"❌ Frontend validation failed: {e}"


def run_all_validations() -> Dict[str, Tuple[bool, str]]:
    """Run all validation tests"""
    validations = {
        "Backend Health": validate_backend_health,
        "Model Files": validate_model_files,
        "Synthetic Data": validate_synthetic_data,
        "AIRI Scoring": validate_airi_scoring,
        "Simulation": validate_simulation_endpoint,
        "Privacy Compliance": validate_privacy_compliance,
        "Frontend Access": validate_frontend_accessibility
    }
    
    results = {}
    
    print("🔍 Running AIRI System Validation...")
    print("=" * 50)
    
    for test_name, test_func in validations.items():
        print(f"\n{test_name}:")
        try:
            success, message = test_func()
            results[test_name] = (success, message)
            print(f"  {message}")
        except Exception as e:
            results[test_name] = (False, f"❌ Test failed with exception: {e}")
            print(f"  ❌ Test failed with exception: {e}")
    
    return results


def main():
    """Main validation function"""
    results = run_all_validations()
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 VALIDATION SUMMARY")
    print("=" * 50)
    
    passed = sum(1 for success, _ in results.values() if success)
    total = len(results)
    
    print(f"\nTests Passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 ALL VALIDATIONS PASSED - AIRI is ready for demo!")
        print("\n🚀 Quick Start:")
        print("  Backend: http://localhost:8000")
        print("  Frontend: http://localhost:5173")
        print("  API Docs: http://localhost:8000/docs")
        return 0
    else:
        print("⚠️  Some validations failed. Please fix issues before demo.")
        print("\n❌ Failed Tests:")
        for test_name, (success, message) in results.items():
            if not success:
                print(f"  - {test_name}: {message}")
        return 1


if __name__ == "__main__":
    sys.exit(main())