#!/usr/bin/env python3
"""
scripts/generate_demo_scores.py
Generate demo AIRI scores from trained model for all districts
"""

import sys
import os
from pathlib import Path

# Add app to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np
import joblib
import json
import shap
from app.scoring import compute_airi_score
from app.utils.decision_engine import get_recommended_action, shap_to_sentence


def generate_scores():
    """Generate AIRI scores for all synthetic districts"""
    
    print("Generating demo AIRI scores...")
    
    # Load synthetic districts
    df = pd.read_csv("data/synthetic_districts.csv")
    
    # Load model and feature metadata
    model = joblib.load("models/model.joblib")
    with open("models/feature_metadata.json") as f:
        metadata = json.load(f)
    
    feature_cols = metadata['features']
    
    # Engineer features (same as training)
    feature_data = df.copy()
    for window in [7, 14, 30]:
        total = df[f'event_count_{window}d']
        feature_data[f'total_events_{window}d'] = total
        if window == 30:
            feature_data[f'rejected_rate_{window}d'] = df['rejected_count_60d'] / (total + 1)
            feature_data[f'biometric_fail_rate_{window}d'] = df['biometric_fail_count_60d'] / (total + 1)
    
    feature_data['device_burstiness'] = df['device_event_std'] / (df['device_event_mean'] + 1)
    feature_data['center_burstiness'] = df['center_event_std'] / (df['center_event_mean'] + 1)
    feature_data['pct_elderly'] = df['age_60plus_count'] / (df['total_population'] + 1)
    feature_data['pct_children'] = df['age_0_17_count'] / (df['total_population'] + 1)
    feature_data['mobile_camp_coverage'] = df['mobile_camp_events'] / (df['total_population'] + 1)
    feature_data['processing_time_anomaly'] = df['processing_time_p95'] / (df['processing_time_median'] + 1)
    feature_data['repeat_update_rate'] = df['repeat_update_count'] / (df['event_count_30d'] + 1)
    
    X = feature_data[feature_cols].fillna(0).astype(np.float32)
    
    # Predict probabilities
    probs = model.predict(X, num_iteration=model.best_iteration)
    
    # Generate SHAP explanations (sample-based to save time)
    print("Computing SHAP values (using TreeExplainer)...")
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    # If binary classification, shap_values is [neg_shap, pos_shap]
    if isinstance(shap_values, list):
        shap_values = shap_values[1]  # Use positive class
    
    scores = []
    
    for idx, row in df.iterrows():
        # AIRI score
        prob = probs[idx]
        confidence = 1.0 - abs(prob - 0.5) * 2  # Higher near 0.5, lower at extremes
        airi_score = compute_airi_score(prob, confidence)
        
        # Risk band
        if airi_score >= 75:
            risk_band = "Critical"
        elif airi_score >= 50:
            risk_band = "High"
        elif airi_score >= 25:
            risk_band = "Medium"
        else:
            risk_band = "Low"
        
        # Top SHAP drivers
        top_features_idx = np.argsort(np.abs(shap_values[idx]))[-3:][::-1]
        drivers = []
        for feat_idx in top_features_idx:
            feat_name = feature_cols[feat_idx]
            shap_val = float(shap_values[idx][feat_idx])
            drivers.append({
                "feature": feat_name,
                "shap_value": shap_val,
                "feature_value": float(X.iloc[idx][feat_idx])
            })
        
        # Explanation
        explanation = shap_to_sentence(drivers)
        
        # Recommended action
        action = get_recommended_action(risk_band, drivers, row)
        
        scores.append({
            "district": row['district'],
            "state": row['state'],
            "latitude": float(row['latitude']),
            "longitude": float(row['longitude']),
            "risk_score": float(airi_score),
            "risk_band": risk_band,
            "probability": float(prob),
            "confidence": float(confidence),
            "drivers": drivers,
            "explanation": explanation,
            "recommended_action": {
                "action": action.action,
                "expected_impact": action.expected_impact,
                "cost_band": action.cost_band,
                "priority": action.priority
            },
            "events_30d": int(row['event_count_30d']),
            "population": int(row['total_population'])
        })
    
    # Save scores
    Path("data").mkdir(exist_ok=True)
    with open("data/demo_scores.json", 'w') as f:
        json.dump(scores, f, indent=2)
    
    print(f"Generated {len(scores)} district scores")
    print(f"Saved to data/demo_scores.json")
    print(f"\nScore distribution:")
    risk_counts = pd.Series([s['risk_band'] for s in scores]).value_counts()
    print(risk_counts)


if __name__ == '__main__':
    generate_scores()
