#!/bin/bash
# scripts/run_demo.sh
# Complete AIRI demo startup script

set -e

echo "================================"
echo "AIRI Demo Startup"
echo "================================"

# Create necessary directories
echo "[1/4] Setting up directories..."
mkdir -p data models data/uploads
echo "✓ Directories ready"

# Generate synthetic data and train model
echo ""
echo "[2/4] Initializing demo model and synthetic data..."
python scripts/init_demo_model.py
echo "✓ Model and data ready"

# Start backend API
echo ""
echo "[3/4] Starting backend API..."
echo "Backend starting on http://localhost:8000"
echo "API docs available at http://localhost:8000/docs"
echo ""

# Run FastAPI app
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
