"""
scripts/init_demo_model.py
Initialize LightGBM model + synthetic data for AIRI demo
"""

import pandas as pd
import numpy as np
import joblib
import json
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_recall_curve, f1_score
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import IsolationForest
from lightgbm import LGBMClassifier
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')


def generate_synthetic_districts(n_districts: int = 100) -> pd.DataFrame:
    """
    Generate realistic synthetic district data for demo.
    
    Returns:
        DataFrame with district-level features
    """
    np.random.seed(42)
    
    # Real Indian districts for authenticity
    indian_districts = [
        ("Uttar Pradesh", "Lucknow", 26.8467, 80.9462),
        ("Uttar Pradesh", "Gorakhpur", 26.7606, 83.3732),
        ("Uttar Pradesh", "Agra", 27.1767, 78.0081),
        ("Maharashtra", "Mumbai", 19.0760, 72.8777),
        ("Maharashtra", "Pune", 18.5204, 73.8567),
        ("Maharashtra", "Nagpur", 21.1458, 79.0882),
        ("Bihar", "Patna", 25.5941, 85.1376),
        ("Bihar", "Gaya", 24.7955, 84.9994),
        ("Bihar", "Muzaffarpur", 26.1209, 85.3647),
        ("West Bengal", "Kolkata", 22.5726, 88.3639),
        ("West Bengal", "Darjeeling", 27.0360, 88.2627),
        ("Madhya Pradesh", "Bhopal", 23.2599, 77.4126),
        ("Madhya Pradesh", "Indore", 22.7196, 75.8577),
        ("Tamil Nadu", "Chennai", 13.0827, 80.2707),
        ("Tamil Nadu", "Coimbatore", 11.0168, 76.9558),
        ("Rajasthan", "Jaipur", 26.9124, 75.7873),
        ("Rajasthan", "Jodhpur", 26.2389, 73.0243),
        ("Karnataka", "Bengaluru", 12.9716, 77.5946),
        ("Karnataka", "Mysuru", 12.2958, 76.6394),
        ("Gujarat", "Ahmedabad", 23.0225, 72.5714),
        ("Gujarat", "Surat", 21.1702, 72.8311),
        ("Andhra Pradesh", "Visakhapatnam", 17.6868, 83.2185),
        ("Andhra Pradesh", "Vijayawada", 16.5062, 80.6480),
        ("Telangana", "Hyderabad", 17.3850, 78.4867),
        ("Kerala", "Thiruvananthapuram", 8.5241, 76.9366),
        ("Assam", "Guwahati", 26.1445, 91.7362),
        ("Punjab", "Ludhiana", 30.9010, 75.8573),
        ("Haryana", "Gurugram", 28.4595, 77.0266),
        ("Jharkhand", "Ranchi", 23.3441, 85.3096),
        ("Odisha", "Bhubaneswar", 20.2961, 85.8245),
        ("Chhattisgarh", "Raipur", 21.2514, 81.6296),
        ("Delhi", "New Delhi", 28.6139, 77.2090),
    ]
    
    # Extend list if needed
    if n_districts > len(indian_districts):
        extended = indian_districts * (n_districts // len(indian_districts) + 1)
        sampled = extended[:n_districts]
    else:
        sampled = np.random.choice(len(indian_districts), n_districts, replace=False)
        sampled = [indian_districts[i] for i in sampled]
    
    data = []
    
    for idx, (state, district, lat, lon) in enumerate(sampled):
        # Add variation to coordinates for duplicates
        lat_var = np.random.uniform(-0.05, 0.05)
        lon_var = np.random.uniform(-0.05, 0.05)
        lat = np.clip(lat + lat_var, 8.0, 37.0)
        lon = np.clip(lon + lon_var, 68.0, 97.0)
        
        # Base enrollment volume (varies by urbanization)
        base_volume = np.random.randint(500, 5000)
        
        # Time windows with realistic patterns
        events_7d = max(0, int(np.random.normal(base_volume * 0.2, base_volume * 0.05)))
        events_14d = max(0, int(np.random.normal(base_volume * 0.4, base_volume * 0.08)))
        events_30d = max(0, int(np.random.normal(base_volume, base_volume * 0.15)))
        
        # Failure patterns (some districts have systematic issues)
        failure_base_rate = np.random.uniform(0.02, 0.15)
        rejected_count_60d = max(0, int(np.random.poisson(events_30d * 2 * failure_base_rate)))
        
        biometric_fail_rate = np.random.uniform(0.01, 0.10)
        biometric_fail_count_60d = max(0, int(np.random.poisson(events_30d * 2 * biometric_fail_rate)))
        
        success_count_90d = max(0, int(events_30d * 3 * (1 - failure_base_rate - biometric_fail_rate) + np.random.normal(0, 50)))
        
        # Device and center statistics
        n_devices = np.random.randint(5, 50)
        device_event_mean = events_30d / n_devices
        device_event_std = device_event_mean * np.random.uniform(0.3, 1.0)
        
        n_centers = np.random.randint(3, 20)
        center_event_mean = events_30d / n_centers
        center_event_std = center_event_mean * np.random.uniform(0.3, 1.2)
        
        # Demographics
        total_population = np.random.randint(50000, 500000)
        age_60plus_count = int(total_population * np.random.uniform(0.05, 0.15))
        age_0_17_count = int(total_population * np.random.uniform(0.20, 0.40))
        
        # Mobile camp coverage
        mobile_camp_events = max(0, int(np.random.poisson(events_30d * 0.1)))
        
        # Processing times
        processing_time_median = np.random.uniform(40, 120)
        processing_time_p95 = processing_time_median * np.random.uniform(1.5, 3.5)
        
        # Repeat updates
        repeat_update_count = max(0, int(np.random.poisson(events_30d * 0.05)))
        
        data.append({
            'state': state,
            'district': district,
            'latitude': lat,
            'longitude': lon,
            'event_count_7d': events_7d,
            'event_count_14d': events_14d,
            'event_count_30d': events_30d,
            'rejected_count_60d': rejected_count_60d,
            'biometric_fail_count_60d': biometric_fail_count_60d,
            'success_count_90d': success_count_90d,
            'device_event_mean': device_event_mean,
            'device_event_std': device_event_std,
            'center_event_mean': center_event_mean,
            'center_event_std': center_event_std,
            'age_60plus_count': age_60plus_count,
            'age_0_17_count': age_0_17_count,
            'total_population': total_population,
            'mobile_camp_events': mobile_camp_events,
            'processing_time_median': processing_time_median,
            'processing_time_p95': processing_time_p95,
            'repeat_update_count': repeat_update_count
        })
    
    return pd.DataFrame(data)


def create_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create engineered features for AIRI model.
    
    Returns:
        DataFrame with additional feature columns
    """
    features = df.copy()
    
    # Core rate features (primary exclusion indicators)
    features['failure_rate_30d'] = features['rejected_count_60d'] / (features['event_count_30d'] + 1)
    features['biometric_fail_rate_30d'] = features['biometric_fail_count_60d'] / (features['event_count_30d'] + 1)
    features['success_rate_90d'] = features['success_count_90d'] / (features['event_count_30d'] * 3 + 1)
    
    # Volume trends and ratios
    features['events_7d_to_30d_ratio'] = features['event_count_7d'] / (features['event_count_30d'] + 1)
    features['events_14d_to_30d_ratio'] = features['event_count_14d'] / (features['event_count_30d'] + 1)
    features['volume_trend'] = (features['event_count_7d'] * 4 - features['event_count_30d']) / (features['event_count_30d'] + 1)
    
    # Device and center utilization patterns
    features['device_burstiness'] = features['device_event_std'] / (features['device_event_mean'] + 1)
    features['center_congestion'] = features['center_event_mean'] / 100  # Events per center per day
    
    # Demographics impact
    features['elderly_ratio'] = features['age_60plus_count'] / (features['event_count_30d'] + 1)
    features['children_ratio'] = features['age_0_17_count'] / (features['event_count_30d'] + 1)
    features['dependency_ratio'] = (features['age_60plus_count'] + features['age_0_17_count']) / (features['event_count_30d'] + 1)
    
    # Processing efficiency
    features['processing_time_ratio'] = features['processing_time_p95'] / (features['processing_time_median'] + 1)
    features['processing_efficiency'] = 60 / (features['processing_time_median'] + 1)
    
    # Repeat patterns
    features['repeat_rate'] = features['repeat_update_count'] / (features['event_count_30d'] + 1)
    
    # Mobile camp accessibility
    features['mobile_camp_coverage'] = features['mobile_camp_events'] / (features['event_count_30d'] + 1)
    
    # Composite operational stress
    features['operational_stress'] = (
        features['failure_rate_30d'] * 0.3 +
        features['device_burstiness'] * 0.2 +
        features['processing_time_ratio'] * 0.2 +
        features['repeat_rate'] * 0.3
    )
    
    return features


def create_realistic_labels(df: pd.DataFrame) -> pd.Series:
    """
    Create realistic exclusion risk labels.
    
    Conservative approach: District labeled high-risk if:
    - Failure rate > 75th percentile AND biometric failures > median
    - OR operational stress > 80th percentile
    
    Returns:
        Binary labels (1 = high exclusion risk)
    """
    failure_threshold = df['failure_rate_30d'].quantile(0.75)
    biometric_threshold = df['biometric_fail_rate_30d'].median()
    stress_threshold = df['operational_stress'].quantile(0.80)
    
    high_failure_bio = (df['failure_rate_30d'] > failure_threshold) & (df['biometric_fail_rate_30d'] > biometric_threshold)
    high_stress = df['operational_stress'] > stress_threshold
    
    labels = (high_failure_bio | high_stress).astype(int)
    
    return labels


def train_demo_model(X: pd.DataFrame, y: pd.Series) -> tuple:
    """
    Train calibrated LightGBM model for demo.
    
    Returns:
        (model, scaler, metrics, feature_importance)
    """
    # Standardize features
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X),
        columns=X.columns,
        index=X.index
    )
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # LightGBM parameters
    lgb_params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'boosting_type': 'gbdt',
        'num_leaves': 31,
        'max_depth': 6,
        'learning_rate': 0.05,
        'feature_fraction': 0.9,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'min_child_samples': 20,
        'reg_alpha': 0.1,
        'reg_lambda': 0.1,
        'verbose': -1,
        'random_state': 42
    }
    
    # Train base model
    model = LGBMClassifier(**lgb_params, n_estimators=500)
    
    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        callbacks=[
            lgb.early_stopping(50, verbose=False),
            lgb.log_evaluation(0)
        ]
    )
    
    # Calibrate probabilities
    calibrated_model = CalibratedClassifierCV(model, method='isotonic', cv=3)
    calibrated_model.fit(X_train, y_train)
    
    # Evaluate
    y_pred_proba = calibrated_model.predict_proba(X_test)[:, 1]
    y_pred = calibrated_model.predict(X_test)
    
    # Metrics
    auc = roc_auc_score(y_test, y_pred_proba)
    f1 = f1_score(y_test, y_pred)
    
    # Precision at K
    def precision_at_k(y_true, y_scores, k):
        if len(y_true) < k:
            k = len(y_true)
        if k == 0:
            return 0.0
        top_k_idx = np.argsort(y_scores)[-k:]
        return np.mean(y_true.iloc[top_k_idx])
    
    precision_at_50 = precision_at_k(y_test, y_pred_proba, k=50)
    precision_at_100 = precision_at_k(y_test, y_pred_proba, k=100)
    
    # PR-AUC
    precision, recall, _ = precision_recall_curve(y_test, y_pred_proba)
    pr_auc = np.trapz(precision, recall)
    
    metrics = {
        'roc_auc': auc,
        'pr_auc': pr_auc,
        'f1_score': f1,
        'precision_at_50': precision_at_50,
        'precision_at_100': precision_at_100
    }
    
    # Feature importance
    importance = pd.DataFrame({
        'feature': X.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    return calibrated_model, scaler, metrics, importance


def generate_demo_scores(model, scaler, df: pd.DataFrame, feature_cols: list) -> list:
    """
    Generate AIRI scores for all districts.
    
    Returns:
        List of district score dictionaries
    """
    from app.scoring import compute_airi_score
    from app.utils.decision_engine import get_recommended_action, shap_to_sentence
    import shap
    
    # Prepare features
    X = df[feature_cols].fillna(0)
    X_scaled = pd.DataFrame(
        scaler.transform(X),
        columns=X.columns,
        index=X.index
    )
    
    # Predict
    risk_probs = model.predict_proba(X_scaled)[:, 1]
    
    # Compute SHAP values for explainability
    explainer = shap.TreeExplainer(model.base_estimator)
    shap_values = explainer.shap_values(X_scaled)
    
    if isinstance(shap_values, list):
        shap_values = shap_values[1]  # positive class
    
    scores = []
    
    for i, row in df.iterrows():
        risk_prob = risk_probs[i]
        confidence = np.abs(risk_prob - 0.5) * 2  # Distance from decision boundary
        
        # AIRI score
        airi_score = compute_airi_score(risk_prob, confidence)
        
        # Risk band
        if airi_score >= 75:
            risk_band = "critical"
        elif airi_score >= 50:
            risk_band = "high"
        elif airi_score >= 25:
            risk_band = "medium"
        else:
            risk_band = "low"
        
        # Top 3 SHAP drivers
        feature_shap = pd.DataFrame({
            'feature': X.columns,
            'shap_value': shap_values[i],
            'feature_value': X_scaled.iloc[i].values
        })
        
        top_3 = feature_shap.reindex(feature_shap['shap_value'].abs().nlargest(3).index)
        
        drivers = [
            {
                'feature': row_shap['feature'],
                'shap_value': float(row_shap['shap_value']),
                'feature_value': float(row_shap['feature_value'])
            }
            for _, row_shap in top_3.iterrows()
        ]
        
        # Explanation
        explanation = shap_to_sentence(drivers)
        
        # Recommended action
        action = get_recommended_action(risk_band, drivers, row)
        
        # Citizens impacted estimate
        impact_factor = max(0.1, (airi_score - 25) / 100)
        citizens_impacted = int(impact_factor * row.get('total_population', 50000))
        
        score_dict = {
            'district': row['district'],
            'state': row['state'],
            'risk_score': airi_score,
            'risk_band': risk_band,
            'shap_drivers': drivers,
            'explanation': explanation,
            'recommended_action': {
                'action': action.action,
                'expected_impact': action.expected_impact,
                'cost_band': action.cost_band,
                'priority': action.priority
            },
            'citizens_impacted': citizens_impacted,
            'latitude': row['latitude'],
            'longitude': row['longitude']
        }
        
        scores.append(score_dict)
    
    return scores


def main():
    """Initialize demo model and data"""
    
    print("🚀 Initializing AIRI Demo Model...")
    
    # Create directories
    Path("data").mkdir(exist_ok=True)
    Path("models").mkdir(exist_ok=True)
    
    # 1. Generate synthetic districts
    print("📊 Generating synthetic district data...")
    df = generate_synthetic_districts(n_districts=100)
    
    # Save raw data
    df.to_csv("data/synthetic_districts.csv", index=False)
    print(f"✅ Saved {len(df)} districts to data/synthetic_districts.csv")
    
    # 2. Create features
    print("🔧 Engineering features...")
    df_features = create_engineered_features(df)
    
    # 3. Create labels
    print("🏷️ Creating exclusion risk labels...")
    y = create_realistic_labels(df_features)
    print(f"   Positive rate: {y.mean():.1%} ({y.sum()}/{len(y)} districts)")
    
    # 4. Select feature columns
    feature_cols = [col for col in df_features.columns if col not in [
        'district', 'state', 'latitude', 'longitude'
    ]]
    
    X = df_features[feature_cols].fillna(0)
    
    print(f"   Features: {len(feature_cols)}")
    
    # 5. Train model
    print("🤖 Training calibrated LightGBM model...")
    model, scaler, metrics, importance = train_demo_model(X, y)
    
    print("📈 Model Performance:")
    for metric, value in metrics.items():
        print(f"   {metric}: {value:.3f}")
    
    print("🔝 Top 5 Features:")
    for _, row in importance.head(5).iterrows():
        print(f"   {row['feature']}: {row['importance']:.3f}")
    
    # 6. Save model artifacts
    print("💾 Saving model artifacts...")
    
    # Save model
    joblib.dump(model, "models/model.joblib")
    
    # Save scaler
    joblib.dump(scaler, "models/scaler.joblib")
    
    # Save metadata
    metadata = {
        'features': feature_cols,
        'metrics': metrics,
        'feature_importance': importance.to_dict('records'),
        'training_date': pd.Timestamp.now().isoformat(),
        'model_type': 'LightGBM_Calibrated',
        'n_districts': len(df),
        'positive_rate': float(y.mean()),
        'demo_mode': True
    }
    
    with open("models/feature_metadata.json", 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("✅ Saved model to models/model.joblib")
    print("✅ Saved metadata to models/feature_metadata.json")
    
    # 7. Generate demo scores
    print("🎯 Generating AIRI scores for all districts...")
    scores = generate_demo_scores(model, scaler, df_features, feature_cols)
    
    # Save scores
    with open("data/demo_scores.json", 'w') as f:
        json.dump(scores, f, indent=2)
    
    print(f"✅ Saved {len(scores)} district scores to data/demo_scores.json")
    
    # Summary statistics
    risk_counts = pd.Series([s['risk_band'] for s in scores]).value_counts()
    avg_score = np.mean([s['risk_score'] for s in scores])
    
    print("\n🎯 AIRI Demo Ready!")
    print(f"   Average AIRI Score: {avg_score:.1f}")
    print(f"   Risk Distribution: {dict(risk_counts)}")
    print(f"   Model Precision@100: {metrics['precision_at_100']:.1%}")
    print(f"   Model ROC-AUC: {metrics['roc_auc']:.3f}")
    
    print("\n🚀 Ready to launch! Run:")
    print("   Backend: python -m uvicorn app.main:app --reload")
    print("   Frontend: cd frontend && npm run dev")


if __name__ == '__main__':
    main()