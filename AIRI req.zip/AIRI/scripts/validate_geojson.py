"""
scripts/validate_geojson.py
Verify GeoJSON CRS, properties, and geometry validity
"""

import sys
from pathlib import Path
from app.utils.geo_utils import validate_geojson, reproject_to_wgs84


def main():
    """
    Validate uploaded GeoJSON file for AIRI requirements.
    """
    if len(sys.argv) < 2:
        print("Usage: python validate_geojson.py <geojson_path>")
        print("\nRequired GeoJSON format:")
        print("- Coordinate system: WGS84 (EPSG:4326)")
        print("- Required properties: district_name, district_id, state_name")
        print("- Valid polygon geometries")
        sys.exit(1)
    
    geojson_path = sys.argv[1]
    
    if not Path(geojson_path).exists():
        print(f"ERROR: File not found: {geojson_path}")
        sys.exit(1)
    
    print(f"Validating GeoJSON: {geojson_path}")
    print("-" * 50)
    
    # Validate
    result = validate_geojson(geojson_path)
    
    if result["valid"]:
        print("✅ VALIDATION PASSED")
        print(f"Districts: {result['districts']}")
        print(f"States: {result['states']}")
        print(f"Bounds: {result['bounds']}")
        
        # Check if reprojection is needed
        try:
            output_path = geojson_path.replace('.geojson', '_wgs84.geojson')
            reprojected = reproject_to_wgs84(geojson_path, output_path)
            
            if reprojected:
                print(f"📍 Reprojected to WGS84: {output_path}")
            else:
                print("📍 Already in WGS84")
        
        except Exception as e:
            print(f"⚠️  Reprojection check failed: {e}")
    
    else:
        print("❌ VALIDATION FAILED")
        print(f"Error: {result['error']}")
        print("\nRequired format:")
        print("- File: india_districts.geojson")
        print("- CRS: WGS84 (EPSG:4326)")
        print("- Properties: district_name, district_id, state_name")
        print("- Geometry: Valid polygons")
        sys.exit(1)


if __name__ == '__main__':
    main()