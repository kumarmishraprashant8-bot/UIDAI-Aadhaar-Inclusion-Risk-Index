# AIRI Privacy & Data Protection

## Core Privacy Principles

**AIRI is privacy-first by design.** All sensitive personally identifiable information (PII) is hashed, aggregated, or excluded entirely. The system operates on district-level aggregates only.

## Data Safeguards

### 1. No Direct PII
- **NEVER stored**: Aadhaar numbers, raw biometric data, names, addresses
- **Hashing & Salting**: If biometric hashes are used (for duplicate detection), they are salted SHA-256 hashes and never reversible

### 2. Aggregation Level
- **Default**: District level (minimum ~50,000 population)
- **K-Anonymity**: All aggregates ensure k ≥ 5 (at least 5 individuals per group)
- **Suppression**: Any cell with count < 5 is suppressed (displayed as `<5`)

### 3. Differential Privacy (Optional)
For public-facing aggregates, apply Laplace mechanism:
```python
def add_laplace_noise(value, epsilon=1.0):
    """Add calibrated noise for epsilon-differential privacy"""
    sensitivity = 1
    scale = sensitivity / epsilon
    noise = np.random.laplace(0, scale)
    return max(0, value + noise)
```
**Recommended epsilon**: 1.0 for counts, 0.1 for rates

### 4. Evidence Packets (Internal View Only)
- Hashed Record IDs (SHA-256)
- Hashed Device/Operator IDs
- No raw identifiers
- **RBAC required**: Only authorized investigators can access

### 5. Demo Mode Safety
- All demo data is **synthetic**
- Clearly labeled: "DEMO MODE" banner on every page
- No real citizen data in demos

## Data Retention
- Aggregates: Retain for 90 days
- Raw uploads: Delete after processing (24-48 hours)
- Model artifacts: Version-controlled, no PII

## Compliance
- GDPR Article 5: Data minimization, purpose limitation
- IT Act 2000 (India): Reasonable security practices
- Aadhaar Act 2016: No unauthorized storage of Aadhaar numbers

## Security Checklist
- [ ] All uploads processed server-side (no client storage)
- [ ] HTTPS enforced in production
- [ ] No logging of PII
- [ ] Access logs anonymized (IP addresses hashed)
- [ ] Regular security audits

## Pilot Deployment
**Before** launching pilot:
1. Conduct Privacy Impact Assessment (PIA)
2. Obtain explicit consent from data controllers
3. Sign Data Processing Agreement (DPA)
4. Enable audit logging
5. Train operators on privacy protocols