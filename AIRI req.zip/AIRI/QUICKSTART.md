# AIRI Quick Start Guide

## 🚀 Launch in 5 Minutes

### Option 1: Docker Compose (Recommended)

```bash
# 1. Build and run both backend and frontend
docker-compose up

# 2. Open browser
# Frontend: http://localhost:5173
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/docs
```

---

### Option 2: Manual Setup (Windows/Mac/Linux)

#### Terminal 1: Backend

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Initialize demo model (generates synthetic data)
python scripts/init_demo_model.py

# 3. Start API server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

**Expected output:**
```
INFO:     Uvicorn running on http://0.0.0.0:8000
```

#### Terminal 2: Frontend

```bash
# 1. Navigate to frontend
cd frontend

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev
```

**Expected output:**
```
  VITE v4.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
```

#### Terminal 3 (Optional): Validation

```bash
# Check if everything is working
python scripts/validate.py
```

---

## 🧪 Testing the System

### 1. Test Backend API

```bash
# Health check
curl http://localhost:8000/health

# Get latest scores
curl http://localhost:8000/scores/latest?limit=10

# Get specific district
curl http://localhost:8000/scores/lucknow
```

### 2. Test Frontend

- Open http://localhost:5173
- Click "Enter Dashboard"
- See 50 synthetic districts with risk scores
- Click on a district marker on the map
- View detailed analysis panel

### 3. View API Documentation

- Go to http://localhost:8000/docs
- Interactive Swagger documentation
- Try API endpoints directly

---

## 📊 What You'll See

### Dashboard KPIs
- **National AIRI Score**: Average risk across all districts
- **High-Risk Districts**: Count of critical/high-risk areas
- **Citizens at Risk**: Estimated population affected
- **Events Processed**: Total enrollments in 30 days

### Interactive Map
- Red dots: Critical risk (≥75)
- Orange dots: High risk (50-74)
- Yellow dots: Medium risk (25-49)
- Green dots: Low risk (<25)
- Click dots to see details

### District Details
- AIRI Score & Risk Band
- Top 3 Risk Drivers with impact
- Human-readable explanation
- Recommended UIDAI action
- Expected impact & cost

---

## 🔧 Troubleshooting

### Backend won't start
```bash
# Check Python version (need 3.8+)
python --version

# Check if port 8000 is free
lsof -i :8000  # macOS/Linux
netstat -ano | findstr :8000  # Windows

# Try different port
uvicorn app.main:app --port 8001
```

### Frontend won't start
```bash
# Check Node version (need 16+)
node --version

# Clear cache
rm -rf node_modules package-lock.json
npm install
npm run dev
```

### Model not loading
```bash
# Regenerate synthetic data and model
python scripts/init_demo_model.py

# Check files exist
ls models/
# Should see: model.joblib, feature_metadata.json
```

### API returns "No scores available"
```bash
# Re-initialize demo model
python scripts/init_demo_model.py

# Check data directory
ls data/
# Should see: demo_scores.json, synthetic_districts.csv
```

---

## 📁 File Structure After Startup

```
AIRI/
├── app/
│   ├── __init__.py
│   ├── main.py              # ← FastAPI app running on :8000
│   ├── schemas.py
│   ├── scoring.py
│   ├── upload.py
│   └── utils/
│       ├── decision_engine.py
│       └── column_mapper.py
├── frontend/
│   └── src/
│       ├── app.jsx          # ← React app running on :5173
│       ├── components/
│       │   ├── Header.jsx
│       │   ├── DistrictCard.jsx
│       │   ├── MapView.jsx
│       │   └── PrivacyBanner.jsx
│       └── pages/
│           └── DemoMode.jsx
├── scripts/
│   ├── init_demo_model.py   # ← Run this first
│   ├── generate_synthetic_data.py
│   ├── validate.py
│   └── run_demo.sh
├── data/
│   ├── synthetic_districts.csv  # ← Generated
│   ├── demo_scores.json         # ← Generated
│   └── uploads/                 # ← User uploads
├── models/
│   ├── model.joblib             # ← Generated LightGBM model
│   └── feature_metadata.json    # ← Generated metadata
├── requirements.txt             # ← Python dependencies
├── docker-compose.yml           # ← Docker setup
└── README.md                    # ← Full docs
```

---

## 🎓 Demo Data

**100 Synthetic Districts** with realistic patterns:
- Real Indian state and district names
- Geographic coordinates (Leaflet map)
- Realistic enrollment volumes
- Time-window aggregations (7/14/30 days)
- Device/center utilization metrics
- Demographics (age distribution)
- Mobile camp coverage
- Processing times

**Zero PII**: All data is completely synthetic and aggregated.

---

## 🏆 Key Features to Explore

1. **Prediction**
   - AIRI Score (0-100)
   - Risk Band (Critical/High/Medium/Low)
   - Citizens Impacted

2. **Explanation**
   - Top 3 Risk Drivers (SHAP-based)
   - Human-readable summary
   - Feature importance visualization

3. **Action**
   - Recommended intervention
   - Expected impact %
   - Cost band (Low/Medium)
   - Priority level

4. **Privacy**
   - Banner showing synthetic data
   - No Aadhaar numbers
   - Aggregated district level
   - No biometric data

---

## 📞 Need Help?

### Check Logs
```bash
# Backend logs (in backend terminal)
# Watch for errors during startup

# Frontend logs (in frontend terminal)
# Watch for React/Vite compilation errors

# Validation script
python scripts/validate.py
```

### Common Issues

| Issue | Solution |
|-------|----------|
| API returns 404 | Run `python scripts/init_demo_model.py` |
| Map not loading | Check API is running on localhost:8000 |
| "No scores available" | Regenerate model with init script |
| CORS errors | Backend CORS middleware should allow * |

---

## 🎯 Demo Flow (Under 3 minutes)

1. **Start** → Both backend and frontend running
2. **Load** → Dashboard shows synthetic district data
3. **Explore** → Click districts on map, view details
4. **Analyze** → See risk drivers and explanations
5. **Act** → View recommended UIDAI interventions
6. **Conclude** → Privacy-first, explainable predictions

---

**Ready? Start with:**
```bash
docker-compose up
```

Then open: **http://localhost:5173**

Enjoy! 🚀
